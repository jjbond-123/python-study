
# 不可变类型/值类型/基本类型: int,float,bool,tuple,str,None,bytes
# 可变类型/引用类型: list, dict, set

# 值类型: 简单的赋值,没有关联
a = 5
b = a
b = 8
print(a, b)  # 5, 8

# 引用类型: 赋值的同时会有关联
l1 = [1, 2, 3]
l2 = l1
l2[0] = 99
print(l1, l2)  # [99, 2, 3] [99, 2, 3]


# 函数中参数:值类型和引用类型的区别

def f(n, m):  # n=a; m=b
    n += 1
    m['age'] += 1
    # print(n, m)  # 11, {'age': 11}


a = 10
b = {'age': 10}

f(a, b)

print(a, b)  # 10, {'age': 11}



