

# 匿名函数

# 普通函数
def f(x):
    return x*x

print( f(3) )


# lambda 关键字用来定义匿名函数
f2 = lambda x: x*x  # 和上面的f函数功能一模一样
print( f2(3) )


#
f3 = lambda x,y: x+y
print( f3(4, 5) )

# =>
# def f3(x,y):
#     return x+y


# sort(key)
person_list = [
    {'name': '马化腾', 'age': 50},
    {'name': '老干妈', 'age': 60},
    {'name': '马云', 'age': 59},
    {'name': '李彦宏', 'age': 40},
    {'name': '王健林', 'age': 65},
]

# 使用匿名函数
# person_list.sort( key=lambda x: x['age'], reverse=True )

# 使用普通函数
def f(x):
    return x['age']

person_list.sort( key=f, reverse=True )

print(person_list)
print()

# 扩展
# sort
def my_sort(l, key=None):

    # 冒泡排序
    for i in range(len(l)-1):
        for j in range(len(l)-1-i):

            left = l[j]
            right = l[j+1]

            if key:
                # x = {'name': '马化腾', 'age': 50}
                # key = lambda x: x['age']
                left = key(left)
                right = key(right)

            if left > right:
                l[j], l[j+1] = l[j+1], l[j]


ages = [3,2,1,6,5,4,7]
my_sort(ages)
print(ages)  # [1, 2, 3, 4, 5, 6, 7]


my_sort(person_list, key=lambda x: x['age'])
print(person_list)



# __main__
# 后面模块的时候再使用
def f6(x):
    print(x)


print(__name__)  # "__main__"
if __name__ == '__main__':
    f6(1)








