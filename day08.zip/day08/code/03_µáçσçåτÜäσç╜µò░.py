

# 标准的函数
#   f(x,y) = x + y
#   f(1,2)



# 求2个数的和
def f(x, y):
    s = x + y

    # 1. 返回结果
    # 2. 立刻退出函数
    # 3. 默认返回None
    return s
    # print(s)  # 不会执行


s2 = f(1, 2)
print(s2)


# 自定义函数: 我们自己写的
# 内置函数: python内部提供的函数

