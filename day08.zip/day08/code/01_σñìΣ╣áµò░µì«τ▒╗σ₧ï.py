''''''
'''
复习:
    Day01 安装软件
    Day02 进制, 变量, 输入input, 输出print
    Day03 数据类型, 占位符, 运算符, IF语句
    Day04 循环: while, for, break, continue, pass
    Day05 列表list, 数学函数math, 随机数random, 元组tuple
    
    Day06 字典dict, 集合set(了解), 排序算法(冒泡排序,选择器)
    Day07 字符串str
'''
'''
数据类型:
    不可变类型/值类型/基本类型:
        number(int,float)
        bool: True,False
        str: 字符串
        tuple: 元组
        None: 空值
        bytes: 二进制
        
    可变类型/引用类型:
        list: 列表
        dict: 字典
        set: 集合(了解)
    

列表:
    ages = [1,2,3,4,5,6]
    基本操作:
        +: 拼接 
        *: 重复
        len: 列表长度
        [:]: 切片
        index: 下标
    列表的方法:
        增: 
            [重点] append(n): 追加一个元素
            extend([]): 追加一个列表中的所有元素
            insert(index, n): 在指定的下标位置插入元素
        删:
            [重点] pop(index): 弹出指定下标的元素, 默认弹出最后一个元素
            remove(n): 删除指定的第一个元素
                count(n): 统计元素出现的次数
            clear(): 清空列表
            del ages[1]: 了解
        改:
            ages[1] = 100
        查:
            print(ages[1])
        
        遍历列表:
            for n in ages:
                pass
            for i in range(len(ages)):
                pass
            for i,n in enumerate(ages):
                pass
        
        排序:
            sort(): 升序 
                sorted(): 升序,不会改变原列表,主要针对元组,字符串的排序
                降序: sort(reverse=True)
            reverse(): 倒序/逆序/反转
                reversed(): 倒序,不会改变原列表,主要针对元组,字符串的排序
        
        拷贝:
            copy(): 浅拷贝, 一般用于一维列表
            
            import copy
            copy.deepcopy() : 深拷贝,主要用于二维列表或多维列表.
        
字符串:
    s = "hello"
    基本操作:
        +: 拼接 
        *: 重复
        len: 字符串长度
        [:]: 切片
        index: 下标
    
    字符串方法:
        find(): 查找子字符串在长字符串中第一次出现的下标位置, 如果不存在则返回-1 
            rfind(): 和find功能类似,但是是从右往左
        split(): 根据分隔符取进行分割/拆分
            splitlines(): 按行分割,等价于split('\n')
        replace(old, new): 替换
        join(): 跟split反过来, 拼接列表中的元素
            如: "+".join(['a','b'])
        
        upper(): 变成大写
        lower(): 变成小写
        isupper(): 是否为大写
        islower(): 是否为小写
        isdigit(): 是否为数字
        isalpha(): 是否为字母
        isalnum(): 是否为字母或数字
        
        encode(): 字符串=>二进制
        decode(): 二进制=>字符串
        
        eval(), ord(), chr(), startswith(), endswith()

字典:
    d = {"name": "李小璐", "age": 29}
    基本操作:
        len: 字典长度
    字典的方法:
        增/改:
            d['name'] = "PGone"   
            update(): 拼接另一个字典
                如: d.update({"sex": "男"})     
        删:
            [重点]pop(k): 根据key删除元素
            popitem(): 了解, 随机删除一个元素
            clear(): 了解, 清空字典
            del d[key]: 了解
        查:
            print(d['name']): 如果key不存在会报错
            d.get('name'): 如果key不存在不会报错,会返回None
        
        遍历字典:
            for k in d:
                pass
            for k in d.keys():
                pass
            for v in d.values():
                pass    
            for k,v in d.items():
                pass
            
            
'''
ages = []
s = ""
d = {}










