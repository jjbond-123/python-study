''''''

'''
提示: 涉及到要返回的题目,一般需要使用return
初级
1.计算从1到某个数以内所有奇数的和并返回
'''
# 不使用函数
# n = 10
# s = 0
# for i in range(1, n+1):
#     if i%2 == 1:
#         s += i
# print(s)

# 使用函数
def f(n):
    s = 0
    for i in range(1, n + 1):
        if i % 2 == 1:
            s += i
    # print(s)
    return s


s2 = f(100)
s2 = f(10)
print(s2)


'''
2.判断某个数是否是偶数，返回结果(True或False)
'''
def f2(n):
    if n%2 == 0:
        return True
    else:
        return False

result = f2(101)
print(result)


'''
3.判断某个数是否是素数，返回结果(True或False)
'''
def f3(n):
    for i in range(2, n):
        if n%i == 0:
            return False

    return True

res = f3(11)
print(res)

print(f3(13))



# return:
#   1. 存在于函数中
#   2. return是终止函数
# break:
#   1. 存在于循环中
#   2. break是终止当前的循环

