
# TCP通讯 客户端

import socket

# 1. 创建socket对象(客户端)
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 2. 主动连接服务器端
client_socket.connect( ('10.36.139.197', 6668) )

# 3. 发送和接收服务器数据
while True:
    # 发送给服务器
    data = input("输入发送给服务器的数据:")
    client_socket.send(data.encode())

    # 接收服务器数据
    data2 = client_socket.recv(1024)
    print("服务器:", data2.decode())


