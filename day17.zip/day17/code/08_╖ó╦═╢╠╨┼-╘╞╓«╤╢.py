
# 云之讯

import requests
import random

def send_sms(phone, vcode):
    '''
    发送短信
    :param phone: 手机号
    :param vcode: 验证码
    '''

    # 云之讯的短信接口
    url = "https://open.ucpaas.com/ol/sms/sendsms"

    data = {
        "sid": "7d946861e6b2d74b2db38a442a19fd38",
        "token": "8712938e22c34a179b3cea43ff783b68",
        "appid": "36c083fcfdcf47b5b50d6a94fbb0e50c",

        "templateid": "422930",  # 短信模板id
        "param": vcode,  # 验证码
        "mobile": phone,  # 接收验证码的手机号
    }

    # requests
    res = requests.post(url, json=data)
    return res.text


def generate_vcode():
    '''
    生成随机6位验证码
    '''
    vcode = ""
    for _ in range(6):
        vcode += str(random.randint(0, 9))
    return vcode


if __name__ == '__main__':
    vcode = generate_vcode()
    print("vcode:", vcode)

    res = send_sms('18566218480', vcode)
    print(res)

