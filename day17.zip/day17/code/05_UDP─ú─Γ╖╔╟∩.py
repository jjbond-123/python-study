

import socket

client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# 发送飞秋消息
# 1: 表示版本
# 1: 自定义的一个包名
# 王宝强: 表示用户名
# baoqiang: 主机名
# 32: 表示发送数据
# hello你中毒了: 发送的内容
msg = "1:1:王宝强:baoqiang:32:hello你中毒了"

# client_socket.sendto(msg.encode('gbk'), ('10.36.139.197', 2425))

for i in range(10):
    client_socket.sendto(msg.encode('gbk'), ('10.36.139.197', 2425))


