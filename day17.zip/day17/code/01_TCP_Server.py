
# 服务端: Server
# 客户端: Client

# TCP通讯 服务端
import socket

# 1. 创建一个socket对象(服务端)
#    AF_INET: IPV4
#    AF_INET6: IPV6
#   SOCK_STREAM: 表示TCP协议
#   SOCK_DGRAM: 表示UDP协议
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 2. 绑定IP和PORT
server_socket.bind( ('10.36.139.197', 6668) )

# 3. 设置监听数(客户端连接数)
server_socket.listen(5)

# 4. 等待客户端来连接我
print("服务器已启动, 等待客户端连接...")
client, addr = server_socket.accept()  # 会让程序暂停
# (<socket.socket fd=420, family=AddressFamily.AF_INET, type=SocketKind.SOCK_STREAM, proto=0, laddr=('10.36.139.197', 6668), raddr=('10.36.139.197', 60773)>, ('10.36.139.197', 60773))
# print(client)
# print(addr)
print("有客户端连接成功了")

# 5. 连接成功后,就可以开始收发数据了
while True:
    # 接收数据, 阻塞程序(让程序暂停)
    data = client.recv(1024)
    print("客户端说:", data.decode())

    # 发送数据给客户端
    client.send("今晚吃鸡吗".encode())


# 6. 关闭连接
# server_socket.close()
