
# UDP通讯 服务端

import socket

# 1. 创建UDP的socket对象
# SOCK_DGRAM: 表示UDP
server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# 2. 绑定ip和port
server_socket.bind( ('10.36.139.197', 5677) )

# 3. 收发数据
while True:
    # 接收数据, 会阻塞程序
    data, addr = server_socket.recvfrom(1024)
    print(f"客户端{addr}说:", data.decode())

    # 发送
    server_socket.sendto('今晚吃鸡'.encode(), addr)


