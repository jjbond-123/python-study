
import smtplib
from email.mime.text import MIMEText

# 邮箱
# 邮件

# 163的邮箱服务器: smtp.163.com
# smtp端口:25
# 邮箱账号: niejeff@163.com
# 授权码: 123456abcde

smtp_server = "smtp.163.com"
smtp_port = 25

from_email = 'niejeff@163.com'
email_code = '123456abcde'  # 这里不是邮箱密码,而是授权码

to_email = ['niejeff@163.com', '904552498@qq.com']

# 创建邮件
msg = MIMEText("今晚来我家吃鸡")
msg['Subject'] = '大吉大利22'  # 标题
msg['From'] = from_email
msg['To'] = 'niejeff@163.com'

# 创建邮箱对象,来发送邮件
smtp = smtplib.SMTP(smtp_server, smtp_port)  # 连接163邮箱服务器
smtp.login(from_email, email_code)  # 登录163邮箱

smtp.sendmail(from_email, to_email, msg.as_string())

# 关闭
smtp.close()

