
# UDP通讯 客户端
import socket

# 1. 创建UDP的socket对象
client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# 2. 收发数据
while True:
    # 发送数据
    data = input("客户端说:")
    client_socket.sendto(data.encode(), ('10.36.139.197', 5677))

    # 接收数据
    data2, addr = client_socket.recvfrom(1024)
    print("服务器说:", data2.decode())


