# -*- encoding: utf-8 -*-

# #中国
# #python2
# print 'hello'
# print 1<>2
# print 1!=2
#
# # /
# print 10/3
# print 10.0/3
#
# # a = raw_input("input:")
# # a = input("input:")
# # print a
# # print type(a)
#
# print 1<'2'  # True
#
# print 0666
# print 0o666
#
# try:
#     1/0
# except Exception, e:
#     print "error",e
#
#
# print list(xrange(4))

