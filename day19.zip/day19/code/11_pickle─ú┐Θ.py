
# pickle模块
#   作用:
#       将Python对象(列表,字典,元组) 存入文件中, 做一个持久化存储
#       将存入文件的内容取出.

import pickle

# 存入文件
stars = ['鹿晗', '肖战', '蔡徐坤', '王一博', '吴亦凡']

fp = open('stars.txt', 'wb')
pickle.dump(stars, fp)
fp.close()

# 从文件中取出
fp2 = open('stars.txt', 'rb')
res = pickle.load(fp2)
print(res)  # ['鹿晗', '肖战', '蔡徐坤', '王一博', '吴亦凡']
print(type(res))  # <class 'list'>




