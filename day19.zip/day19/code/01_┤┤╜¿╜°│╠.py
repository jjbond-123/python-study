
import multiprocessing


# 方法1
import os


def process1(*args):
    print("子进程:", args)


def create_process1():
    p = multiprocessing.Process(target=process1, args=('故宫', '长城'))
    p.start()
    # p.join()


# 方法2
class MyProcess(multiprocessing.Process):
    def __init__(self):
        super().__init__()

    def run(self):
        print("子进程:", multiprocessing.current_process().name)
        print("进程id:", self.pid)

def create_process2():
    p = MyProcess()
    p.start()
    print("p进程:", p.pid)
    print("主进程:", os.getpid())  # 进程id


if __name__ == '__main__':
    # create_process1()
    create_process2()




