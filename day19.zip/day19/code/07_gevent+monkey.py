import gevent

from gevent import monkey  # 导入猴子补丁
monkey.patch_all()  # 自动切换协程

import requests
import time


def fn(url):
    print("协程:", url)
    response = requests.get(url)
    print(url, len(response.text))


if __name__ == '__main__':
    url_list = [
        'http://www.baidu.com',
        'http://www.qq.com',
        'http://www.ifeng.com',
    ]

    # 创建协程
    g_list = []
    for url in url_list:
        g = gevent.spawn(fn, url)
        g_list.append(g)

    # 执行所有的协程
    gevent.joinall(g_list)



