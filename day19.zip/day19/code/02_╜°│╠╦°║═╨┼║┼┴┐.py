
import multiprocessing
import time


def f(i, lock):
    with lock:
        print(f"第{i}个进程加锁")
        time.sleep(3)
        print(f"第{i}个进程解锁")


def f2(i, sem):
    with sem:
        print(f"子进程{i}开始执行")
        time.sleep(3)
        print(f'子进程{i}结束')


if __name__ == '__main__':

    # 进程锁: 了解
    # lock = multiprocessing.Lock()
    # for i in range(5):
    #     p = multiprocessing.Process(target=f, args=(i, lock))
    #     p.start()

    # 信号量: 控制最大的进程并发数
    sem = multiprocessing.Semaphore(3)
    for i in range(20):
        multiprocessing.Process(target=f2, args=(i, sem)).start()





