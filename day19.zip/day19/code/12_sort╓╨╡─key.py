

# sort()
# sort(reverse=True)


class A:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def __str__(self):
        return f'姓名:{self.name}, 年龄: {self.age}'


# 创建10个对象
a_list = []
for i in range(1, 11):
    a = A(f"张三{i}", 10+i)
    a_list.append(a)


# 按age进行降序
a_list2 = sorted(a_list, key=lambda a:a.age, reverse=True)

for a in a_list2:
    print(a)
