

# 了解
# 高阶函数: 向函数中传入函数

# sorted()
# revesed()

# map() : 可以对某列表中的每个元素进行统一的处理,得到新的列表
list1 = [1, 2, 3, 4]
# list2 = map(lambda x:x**2, list1)
list2 = [i**2 for i in list1]
print(list2)  # map object
print(list(list2))  # [1, 4, 9, 16]

list3 = [1, 2, 3, 4]
list4 = [1, 2, 3, 4]
list5 = map(lambda x,y:x+y, list3, list4)
print(list(list5))  # [2, 4, 6, 8]


# reduce(): 累计运算
from functools import reduce
# n = reduce(lambda x,y:x+y, range(1, 101))
n = reduce(lambda x,y:x*y, range(1, 11))
print(n)

# int 4个字节
# 2^32
# print(2**32)
# print(2**64)


# filter(): 过滤
list5 = [1, 2, 3, 4, 6, 7, 8, 9]
list6 = filter(lambda x:x%3==0, list5)
print(list(list6))  # [3, 6, 9]


