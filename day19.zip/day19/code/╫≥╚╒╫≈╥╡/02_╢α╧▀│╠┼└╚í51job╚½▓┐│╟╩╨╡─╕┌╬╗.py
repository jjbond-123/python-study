
# 多线程爬取51job全部城市岗位，并分别保存到单独的以城市名为文件名的html中，如: 深圳.html
# url = "https://jobs.51job.com/"
import re
import threading
import requests

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36"
}

def get_citys():

    url = "https://jobs.51job.com/"

    response = requests.get(url, headers=headers)
    content = response.content.decode('gbk')
    # print(content)

    pattern = r'class="lkst">(.*?)</div>'
    city_str = re.findall(pattern, content, re.S)[0]
    # print(city_str)

    pattern2 = r'">(.*?)</a>'
    name_list = re.findall(pattern2, city_str, re.S)

    pattern3 = r'href="(.*?)"'
    url_list = re.findall(pattern3, city_str, re.S)

    return name_list, url_list


# 子线程
def save_city(name, url):
    response = requests.get(url, headers=headers)
    with open(f'citys/{name}.html', 'wb') as fp:
        fp.write(response.content)  # 二进制
        fp.flush()


if __name__ == '__main__':

    name_list, url_list = get_citys()

    for i in range(len(name_list)):
        name = name_list[i]
        url = url_list[i]

        t = threading.Thread(target=save_city, args=(name, url))
        t.start()



