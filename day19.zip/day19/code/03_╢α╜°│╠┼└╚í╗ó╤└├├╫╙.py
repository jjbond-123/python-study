import multiprocessing
import re

import requests

# 虎牙颜值主播: https://www.huya.com/g/2168

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36"
}

def get_huya():
    url = 'https://www.huya.com/g/2168'

    response = requests.get(url, headers=headers)
    content = response.text
    # print(content)

    # 获取所有妹子
    pattern = r'"game-live-item"(.*?)</li>'
    meizi_list = re.findall(pattern, content, re.S)

    for meizi in meizi_list:
        # print(meizi)

        # 获取妹子图片
        pattern2 = r'data-original="(.*?)"'
        img_url = re.findall(pattern2, meizi, re.S)[0]

        # 获取妹子名字
        pattern3 = r'alt="(.*?)"'
        name = re.findall(pattern3, meizi, re.S)[-1]
        # print(name)

        # 保存图片
        response2 = requests.get(img_url, headers=headers)
        with open(f'huya/{name}.png', 'wb') as fp:
            fp.write(response2.content)
            fp.flush()


if __name__ == '__main__':

    p = multiprocessing.Process(target=get_huya)
    p.start()



# 自己练习
# 翻页
# page是页码
# https://www.huya.com/cache.php?m=LiveList&do=getLiveListByPage&gameId=2168&tagAll=0&page=3



