
# json: 是中数据格式
# json的2种存在形式:
#   1. json字符串
#   2. json对象


import json

# json字符串 => json对象 : JSON解析/JSON反序列化
json_str = '{"name": "鹿晗", "age": 30}'
json_obj = json.loads(json_str)
print(json_obj)  # {'name': '鹿晗', 'age': 30}
print(type(json_obj))  # <class 'dict'>

# json对象 => json字符串 : JSON序列化 (使用更多)
json_obj = {"name": "鹿晗", "age": 30}
json_str = json.dumps(json_obj)
print(json_str)  # '{"name": "\u9e7f\u6657", "age": 30}'
print(type(json_str))  # <class 'str'>




