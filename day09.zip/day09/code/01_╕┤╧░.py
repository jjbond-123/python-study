

# 函数
# 普通函数
def f(x, y, *args, z=3, **kwargs):
    print(x, y)
    return x+y

f(1,2,3,4,5, z=6,k=7,p=8)
# x=1
# y=2
# args=(3,4,5)
# z=6
# kwargs={'k':7, 'p':8}

# 匿名函数
def f2(x):
    return x**3

# => 匿名函数
f3 = lambda x:x**3
print(f3(3))  # 27

