''''''

# 【以下功能都使用函数封装】
#
# 提示: 涉及到要返回的题目,一般需要使用return
# 初级
# 1.计算从1到某个数以内所有奇数的和并返回
#
# 2.判断某个数是否是偶数，返回结果(True或False)
#
# 3.判断某个数是否是素数，返回结果(True或False)

# 4.计算2-100之间素数的个数，返回结果
def f4():

    count = 0

    for n in range(2, 101):
        if n == 2:
            count += 1
        else:
            for i in range(2, n):
                if n%i == 0:
                    # print("是合数")
                    break
            else:
                # print("是素数")
                count += 1

    # print(count)
    return count

res = f4()
print(res)


# 中级
# 1.比较某两个数的大小，返回较大的一个
def f5(x, y):
    m = max(x, y)
    return m

print(f5(3, 4))


# 2.交换某两个变量的值
def f6(x, y):
    x, y = y, x
    # print(x, y)
    return x, y

print(f6(3, 4))


# 3,封装函数，将某个字符串中的大写字母转换为小写，小写字母转换为大写，将新的字符串返回【参数设置为默认参数】
# # swapcase()
def f7(s="abcABC123"):
    return s.swapcase()

print(f7())  # ABCabc123


# 高级
# 1,定义函数实现如下要求
# 	例如：输入2，5，则求2+22+222+2222+22222的和
def f8(a, n):
    s = 0
    t = 0
    for i in range(n):
        t = t*10 + a
        # print(t)
        s += t
    return s

res = f8(2, 5)
print(res)



# 2,已知千锋邮箱的用户名只能由数字字母下划线组成，域名为@1000phone.com,
#    写一个函数is_legal_email，判断一个字符串是否是千锋邮箱，是返回True，不是返回False。
#      mail@1000phone.com  是
#      $mail@1000phone.com  不是
#      mail@1000phone.comp  不是


def is_legal_email(email):
    list1 = email.split('@')

    if len(list1) != 2:
        return False

    # index = email.rfind('@')
    # name = email[:index]  # ma@il
    # domain = email[index:]  # @1000phone.com

    name = list1[0]  # 用户名
    domain = list1[1]  # 域名

    if domain != "1000phone.com":
        return False

    for c in name:
        if not (c.isalnum() or c=="_"):
            return False

    return True


print(is_legal_email("ma_il@1000phone.com"))


# 61999@1000phone.com



# 返回多个变量
# def f(a, b):
#     s1 = a + b
#     s2 = a - b
#     return s1, s2
#
# res = f(3,2)
# print(res, type(res))  # (5, 1) <class 'tuple'>








