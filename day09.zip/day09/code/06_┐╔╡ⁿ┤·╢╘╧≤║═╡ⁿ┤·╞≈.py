
from collections.abc import Iterable  # 可迭代对象
from collections.abc import Iterator  # 迭代器


# 可迭代对象: 只要可以使用for-in循环就是可迭代对象
#  有: list, tuple, dict, set, str, genarator

# isinstance(): 检测某个对象是否属于某个类
print(isinstance([1,2], Iterable))  # True
print(isinstance((1,2), Iterable))  # True
print(isinstance({}, Iterable))  # True
print(isinstance({1,2}, Iterable))  # True
print(isinstance("ni", Iterable))  # True
print(isinstance((i for i in range(2)), Iterable))  # True

print(isinstance(True, Iterable))  # False
print(isinstance(4, Iterable))  # False

print()


# 迭代器: 既要能用for-in循环,且可以使用next调用
print(isinstance([1,2], Iterator))  # False
print(isinstance((1,2), Iterator))  # False
print(isinstance({}, Iterator))  # False
print(isinstance({1,2}, Iterator))  # False
print(isinstance("ni", Iterator))  # False
print(isinstance((i for i in range(2)), Iterator))  # True

print(isinstance(True, Iterator))  # False
print(isinstance(4, Iterator))  # False


#
# iter() : 将可迭代对象=>迭代器
#
l = [1,2,3]
l2 = iter(l)

print(l2)  # list_iterator object
# print(next(l2))  # 1

print( list(l2) )  # [1, 2, 3]


# 掌握什么是迭代器和可迭代对象




