
#
# 函数嵌套
#

def f1():
    print('f1')

    def f2():
        print('f2')

    # f2()
    return f2


# f2()  # 报错
res = f1()  # res = f2
res()  # 等价于 f2()

# f1()()


# 传参
def f3(a):
    print('f3')

    def f4(b):
        print('f4', a, b)  # f4 3 4

    return f4


res = f3(3)
res(4)  # 等价于 f4(4)


#
# 闭包: 函数嵌套,把内部函数返回, 可以让外部函数中的参数或变量不被释放(让变量不消失)
#

# 局部变量:
#   优点: 不会被外部干扰
#   缺点: 内存会被回收(变量会被删除)
def m1():
    x = 10
m1()
# print(x)  # 会报错

# 全局变量:
#   优点: 内存不会被回收(变量不会被删除)
#   缺点: 可能会被干扰
y = 10
def m2():
    global y
    y = 20


# 闭包的特点: 不会被外部干扰, 内存不会被回收
def out():
    p = 10

    def inner():
        nonlocal p
        p += 1

        print('p =', p)

    return inner


f = out()  # f=inner
f()  # 11 相当于:inner()
f()  # 12
f()  # 13


#
def fx(x, y):
    def fy(n):
        return n*x + y
    return fy


f = fx(3, 5)   # f=fy
# f(n) = 3n + 5
print( f(2) )  # 3*2 + 5
print( f(4) )  # 3*4 + 5

f2 = fx(6, 8)
# f2(n) = 6n + 8
print( f2(3) )





