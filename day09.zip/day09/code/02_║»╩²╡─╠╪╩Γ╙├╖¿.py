

# f: 既是函数名称, 也是指向函数的一个变量
#  所有指向函数的变量都可以调用该函数
def f():
    print("hello")

f()
f2 = f
f2()


a = max
print(a(2,3,1))


#
def fn(x, key):
    # key = lambda x:x*2
    # key = f2

    s = x + key(3)
    print(s)


# fn(1, lambda x:x*2)

def f2(x):
    return x*2
# f3 = f2

fn(1, f2)


# 回调函数
# m1是普通函数
def m1(x, f):
    # x = 3
    # f = m2
    # print(x, f)
    s = f(x)  # f(x) 等价于m2(x)
    print("s =", s)


# m2是回调函数
def m2(a):
    return a + 1
m1(3, m2)

# m3是回调函数
# def m3(a):
#     return a + 2
# m1(3, m3)






