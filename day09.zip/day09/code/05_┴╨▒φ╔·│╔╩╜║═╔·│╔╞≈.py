

# 列表生成式: 快速生成列表

# 创建列表
ages = [20, 30, 40]

ages = []
for i in range(1, 11):
    ages.append(i)
print(ages)

ages = list(range(1, 11))

# 列表生成式/列表推导式
ages = [i for i in range(1, 11)]  # [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
ages = [i*i for i in range(1, 11)]  # [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]

ages = [i for i in range(1, 11) if i%2==1]  # [1, 3, 5, 7, 9]
ages = [i for i in range(1, 11) if i>3 and i<8]  # [4, 5, 6, 7]
ages = [i for i in range(1, 11) if i>3 if i<8]  # [4, 5, 6, 7]
print(ages)

l1 = "abc"
l2 = 'xyz'
l3 = [i+j for i in l1 for j in l2]
print(l3)

# ['ax', 'ay', 'az', 'bx', 'by', 'bz', 'cx', 'cy', 'cz']
#
# for i in l1:
#     for j in l2
#         i+j

# 字典生成式: 了解
d = {i:i+1 for i in range(1, 4)}
print(d)


# 计算代码耗时
import time
start = time.time()  # 获取当前时间

for i in range(1000000):
    pass

end = time.time()
# print(end - start)


# 生成器
# ages = [i for i in range(5)]
# print(ages)  # [0, 1, 2, 3, 4]

# 这里的写法了解即可
ages = (i for i in range(5))
print(ages)  # <generator object <genexpr> at 0x0000013C6A0AE1A8>
# print(list(ages))  # [0, 1, 2, 3, 4]

# 生成器对象: 可以不一次性占用太多内存空间,我们一般需要一个一个元素取出来
# next()
# print(next(ages))  # 0
# print(next(ages))  # 1
# print(next(ages))  # 2
# print(next(ages))  # 3
# print(next(ages))  # 4
# print(next(ages))  # 报错, StopIteration

for i in ages:
    print('i =', i)

print()


# 生成器函数: 在普通函数中包含yield关键字,则是生成器函数
def f():
    print("唧唧复唧唧")
    yield 8
    print("木兰当户织")
    yield 9
    print("不闻机杼声")


gen = f()
print(gen)  # generator object

print(next(gen))
print(next(gen))
# next(gen)  # 报错 StopIteration

# yield:
#   1. 写在函数中,可以让普通函数变成生成器函数
#   2. 可以返回一个值, 但是不会退出函数
#   3. 每次使用next,则会运行至下一个yield



