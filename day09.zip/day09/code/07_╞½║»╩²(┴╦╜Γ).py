

# 偏函数

print( int("10") )  # 10

print( int("1010", base=2) )  # 10
print( int("1010", base=8) )  # 520


import functools
int2 = functools.partial(int, base=2)

print( int2('1010') )  # 10



import calendar

print(calendar.month(1900,1))

'''
    January 1900
Mo Tu We Th Fr Sa Su
 1  2  3  4  5  6  7
 8  9 10 11 12 13 14
15 16 17 18 19 20 21
22 23 24 25 26 27 28
29 30 31

'''