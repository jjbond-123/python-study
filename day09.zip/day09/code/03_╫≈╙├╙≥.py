

# 作用域: 起作用的范围
def f1(x):
    x += 1
    print(x)
    y = 2
    print(y)


f1(10)
# print(x)  # 报错,函数内部的变量,在函数外不能使用
# print(y)  # 报错,函数内部的变量,在函数外不能使用


# 局部变量: 函数内部定义的变量,只能在函数内部使用, 比如:上面的x和y
# 全局变量: 函数外部定义的变量,具有全局作用域

a = 10  # 全局变量

def f2():
    # print(a)  # 10,可以打印全局变量

    # a = 1  # 局部变量,认为是定义了一个新的变量, 尽量避免这种情况,可以换个变量名
    # print(a)

    # 默认不可以修改全局变量
    # global 作用是让a使用的是全局变量a
    global a
    a += 1
    print(a)


f2()
print(a)


# nonlocal: 了解
b = 10

def n1():
    b = 20

    def n2():
        # b = 30  # 此时用的是b=30

        # global b  # 此时用的是b=10
        nonlocal b  # 此时用的是b=20
        b += 1
        print(b)

    n2()

n1()







