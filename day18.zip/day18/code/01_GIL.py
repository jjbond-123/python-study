
# GIL: 全局解释器锁
#   作用: 保证只有一个线程执行
#
# 线程: 因为有GIL的存在,多个线程也只会占用一个CPU
# 进程: 会使用多个CPU


# # 使用线程
# from threading import Thread
# def loop():
#     while True:
#         print("亲爱的，我错了，我能吃饭了吗?")
#
# if __name__ == '__main__':
#     for i in range(3):
#         t = Thread(target=loop)
#         t.start()
#     while True:
#         pass


# 而如果我们变成进程呢？cpu --100%
from multiprocessing import Process
def loop():
    while True:
        print("亲爱的，我错了，我能吃饭了吗?")

if __name__ == '__main__':
    for i in range(3):
        t = Process(target=loop)
        t.start()
    while True:
        pass



