
# 使用多线程爬取斗鱼妹子
# url = "https://www.douyu.com/gapi/rknc/directory/yzRec/3"


# 存储图片
# import requests
# url='https://rpic.douyucdn.cn/live-cover/appCovers/2019/03/09/6523500_20190309142516_small.jpg'
# res = requests.get(url)
# with open('a.png', 'wb') as fp:
#     fp.write(res.content)

import threading
import requests

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36"
}


def get_douyu(page):
    url = f"https://www.douyu.com/gapi/rknc/directory/yzRec/{page}"

    response = requests.get(url, headers=headers)
    content_dict = response.json()
    # print(content_dict)

    meizi_list = content_dict['data']['rl']
    for meizi in meizi_list:
        name = meizi.get('nn')
        photo = meizi.get('rs1')

        print(f'第{page}页:', name, photo)

        # 下载图片,并保存
        response = requests.get(photo, headers=headers)
        with open(f'douyu/{name}.png', 'wb') as fp:
            fp.write(response.content)
            fp.flush()


if __name__ == '__main__':
    for i in range(1, 10):
        t = threading.Thread(target=get_douyu, args=(i,))
        t.start()



