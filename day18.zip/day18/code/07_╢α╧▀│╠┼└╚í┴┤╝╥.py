
# 使用多线程爬取深圳所有区的房源，并分别保存到单独的以区为文件名的html中，如: 南山区.html
# （爬取每个区的第一页即可）
# https://sz.lianjia.com/ershoufang/pg1/
import re
import threading

import requests

# 模拟浏览器
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36"
}


# 获取所有区
def get_area():

    url = 'https://sz.lianjia.com/ershoufang/pg1/'

    # 获取网页数据
    response = requests.get(url, headers=headers)
    content = response.text
    # print(content)

    # 获取所有区
    pattern = r'data-role="ershoufang"(.*?)</div>'
    area_str = re.findall(pattern, content, re.S)[0]
    # print(area_str)

    pattern2 = r'href="(.*?)"'
    area_url_list = re.findall(pattern2, area_str, re.S)
    # print(area_url_list)

    pattern3 = r'">(.*?)</a>'
    area_name_list = re.findall(pattern3, area_str, re.S)
    # print(are_name_list)

    return area_url_list, area_name_list


# 子线程
def get_data(name, url):
    # 每个区的url网址
    url = 'https://sz.lianjia.com' + url
    response = requests.get(url, headers=headers)

    with open(f'lianjia/{name}.html', 'wb') as fp:
        fp.write(response.content)  # 写入二进制


if __name__ == '__main__':
    # 获取所有区
    area_url_list, area_name_list = get_area()

    for i in range(len(area_url_list)):
        name = area_name_list[i]
        url = area_url_list[i]

        t = threading.Thread(target=get_data, args=(name, url))
        t.start()



