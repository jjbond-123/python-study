
import threading
import time

# 信号量: 控制线程的最大并发数,每次最多5个线程同时执行
sem = threading.Semaphore(5)

def fn(*args):
    with sem:
        print("子线程:", args)
        time.sleep(3)


if __name__ == '__main__':
    for i in range(1, 21):
        threading.Thread(target=fn, args=(f"Thread-{i}",)).start()



