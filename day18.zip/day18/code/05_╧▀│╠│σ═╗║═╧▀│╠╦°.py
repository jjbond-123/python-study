
import threading

# 线程冲突: 多个线程同时操作一个资源时,可能造成资源混乱
# 线程锁/互斥锁: 解决线程冲突

# 死锁现象: 多个线程同时操作多个资源时
# 比如:
#   线程1   线程2
#     A     B
#     B     A
# 递归锁/重用锁: 解决死锁

n = 0


def f():
    global n
    for _ in range(1000000):
        n += 1
    print(n)

# 线程冲突
def create_thread():
    # 同时开启5个线程,同时去访问同一个变量n
    for _ in range(5):
        t = threading.Thread(target=f)
        t.start()
        # t.join()  # 同步


# 线程锁: 解决线程冲突
lock = threading.Lock()
# 递归锁: 解决死锁
# rlock = threading.RLock()


def f2():

    # 自动加锁,用完后会自动解锁
    # 加锁过程中其他线程无法访问
    with lock:
    # with rlock:
        global n
        for _ in range(1000000):
            n += 1
        print(n)

    # lock.acquire()  # 加锁
    #
    # global n
    # for _ in range(1000000):
    #     n += 1
    # print(n)
    #
    # lock.release()  # 解锁


def create_thread2():
    for _ in range(5):
        t = threading.Thread(target=f2)
        t.start()


if __name__ == '__main__':
    # 线程冲突
    # create_thread()
    # 线程锁
    create_thread2()
