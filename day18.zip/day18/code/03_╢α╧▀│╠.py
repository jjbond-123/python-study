
import threading
import time
import random


def fn(*args):
    time.sleep(random.random())
    print(f"子线程:{args}")


if __name__ == '__main__':
    # # 多个线程同时在运行, 异步执行(在不同的线程上执行)
    # t1 = threading.Thread(target=fn, args=("韩信1",))
    # t1.start()
    # # t1.join()  # 阻塞 等待t1线程执行完成后才能执行后面的代码
    #
    # t2 = threading.Thread(target=fn, args=("韩信2",))
    # t2.start()
    # # t2.join()
    #
    # t3 = threading.Thread(target=fn, args=("韩信3",))
    # t3.start()
    # # t3.join()

    start = time.time()

    t_list = []

    for i in range(10):
        t = threading.Thread(target=fn, args=('不知火舞-'+str(i),))
        t.start()
        # t.join()  # 同步
        t_list.append(t)

        # 线程的属性和方法: 了解
        print(t.name, t.getName())  # 线程名
        print(t.isDaemon())  # 是否为守护线程, False
        print(t.ident)  # 线程号
        print(t.is_alive())  # 线程是否在运行
        print(threading.active_count())  # 正在运行的线程数量
        print(threading.enumerate())  # 列举所有正在运行的线程
        print()

    # 等待所有线程全部执行完
    for t in t_list:
        t.join()


    print('end')

    end = time.time()
    print(end - start)

