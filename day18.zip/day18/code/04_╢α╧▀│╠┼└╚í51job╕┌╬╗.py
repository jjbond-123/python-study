
import re
import threading
import time

import requests

# 模拟浏览器
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36"
}


# https://search.51job.com/list/040000,000000,0000,00,9,99,python,2,1.html?lang=c&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&ord_field=0&dibiaoid=0&line=&welfare=
# https://search.51job.com/list/040000,000000,0000,00,9,99,python,2,2.html?lang=c&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&ord_field=0&dibiaoid=0&line=&welfare=
# https://search.51job.com/list/040000,000000,0000,00,9,99,python,2,3.html?lang=c&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&ord_field=0&dibiaoid=0&line=&welfare=



def get_jobs(page):

    url = f"https://search.51job.com/list/040000,000000,0000,00,9,99,python,2,{page}.html?lang=c&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&ord_field=0&dibiaoid=0&line=&welfare="

    # 1. 获取网页内容
    response = requests.get(url, headers=headers)
    content = response.content.decode('GBK')
    # print(content)  # 网站内容

    # 2. 获取职位名
    pattern2 = r'"el">(.*?)"el">'
    job_list = re.findall(pattern2, content, re.S)
    # print(job_list)

    for job in job_list:
        # 工作岗位和公司名称
        pattern3 = r'title="(.*?)"'
        job_name = re.findall(pattern3, job)

        # 薪资
        pattern4 = r'"t4">(.*?)</span>'
        salary = re.findall(pattern4, job)

        print(f"第{page}页:", job_name[0], job_name[1], salary[0])


if __name__ == '__main__':

    s = time.time()

    # 同步: 大约消耗4-5秒
    # for i in range(1, 101):
    #     get_jobs(i)

    # 异步: 使用多线程, 大约耗时0.7秒
    t_list = []
    for i in range(1, 101):
        t = threading.Thread(target=get_jobs, args=(i,))
        t.start()
        t_list.append(t)

    for t in t_list:
        t.join()

    e = time.time()
    print(e - s)


