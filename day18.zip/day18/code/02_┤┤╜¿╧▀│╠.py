
# 线程分为:
#   主线程
#   子线程/分线程

import _thread
import time
import threading


# 第一种方式
# 子线程/分线程
def thread1(*args):
    print("线程1:", args)
    print("子线程:", threading.current_thread().name)  # 子线程: Dummy-1

def create_thread1():
    # 当前线程名: MainThread
    print("主线程:", threading.current_thread().name)

    # 创建子线程
    #   守护线程: 子线程会随着主线程的结束而结束
    #   主公就是主线程,忠诚就是子线程
    _thread.start_new_thread(thread1, ("韩信", "刘邦"))

    time.sleep(20)


# 第二种方式
def thread2(*args):
    print("子线程:", args)
    print("子线程:", threading.current_thread().name)
    # 子线程: Thread-1 / 线程1

def create_thread2():
    t = threading.Thread(target=thread2, name='线程1', args=("李白", '杜甫'))
    t.start()  # 启动线程
    print("hello")


# 第三种方式
# 自定义线程
class MyThread(threading.Thread):
    def __init__(self, url):
        super().__init__()
        self.url = url

    # 重写run方法: 会自动调用, 这个函数就是子线程的函数,类似target
    def run(self):
        print("子线程:", threading.current_thread().name)

def create_thread3():
    t = MyThread("http://www.baidu.com")
    t.start()


if __name__ == '__main__':
    # create_thread1()
    # create_thread2()
    create_thread3()

