
# 分支结构
# if : 如果

# if单分支
age = int(input("请输入年龄:"))
if age>=18:
    print("你成年了,可以去网吧了")
    print("还可以玩吃鸡了")

# 注意缩进,一般是4个空格或者一个tab

# 双分支: if-else
if age>=60:
    print("您老了, 该跳广场舞了")
else:
    print("还年轻")


# 多分支: if-elif-else
if age<18:
    print("还未成年")
elif age<40:
    print("青年")
elif age<60:
    print("中年")
else:
    print("老年")


# 比较2个数中最大值
a = 100
b = 20
if a > b:
    print(a)
elif a == b:
    print("a == b")
else:
    print(b)


# 比较3个数中的最大值
a = 20
b = 30
c = 40

if a>b:
    if a>c:
        print("最大值是:", a)
    else:
        print("最大值是:", c)

else:
    if b>c:
        print("最大值是:", b)
    else:
        print("最大值是:", c)








