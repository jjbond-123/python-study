
'''
 数据类型:
    Number:
        int 整数
        float 小数,浮点数
    String: 字符串, "hello", 'hello'
    Boolean: 布尔类型, True, False

    List: 列表, [1,2,3]
    Tuple: 元组, (1,2,3)
    Dict: 字典, {"name": "蔡徐坤"}
    Set: 集合(了解), {1,2,3}
    Bytes: 二进制, b'hello'

    None: 空值类型, None

'''

# Python是弱类型语言
a = 10
print(type(a))  # <class 'int'> 整数
print(id(a))  # 1501996416, 内存地址

a = 10.3
print(type(a))  # <class 'float'> 小数

# string
b = "墨西哥发生了8.0级地震"
print(type(b))  # <class 'str'> 字符串

# boolean
c = True
print(type(c))  # <class 'bool'> 布尔

# list
d = [1, 2, 3]
print(type(d))  # <class 'list'> 列表

# tuple
e = (1, 2, 3)
print(type(e))  # <class 'tuple'> 元组

# dict
f = {"name": "渣渣辉", "age": 50}
print(type(f))  # <class 'dict'> 字典

# set
g = {1, 2, 3}
print(type(g))  # <class 'set'> 集合

# bytes
h = b'hello'
print(type(h))  # <class 'bytes'> 二进制

# None
i = None
print(type(i))  # <class 'NoneType'> 空值








