

# 成员运算符
#  in,  not in
ages = [1, 2, 3, 4]
print(1 in ages)  # True
print(33 not in ages)  # True
# print(not 33 in ages)  # True

# 身份运算符
#  判断内存地址
#  is, is not
a = 10
b = a
print(id(a))  # 1501996416
print(id(b))  # 1501996416

print(a is b)  # True
print(a is not b)  # False


