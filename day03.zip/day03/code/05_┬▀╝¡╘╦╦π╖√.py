
# 逻辑运算符
#   and与, or或, not非

# and 与
# and的两边都为真,则结果为真, 否则为假
print(True and True)  # True
print(True and False)  # False
print(False and True)  # False
print(False and False)  # False
print(3>4 and 4<5)  # False

# or 或
# or的两边都为假,则结果为假,否则为真
print(True or True)  # True
print(True or False)  # True
print(False or True)  # True
print(False or False)  # False
print(3>4 or 4<5)  # True

# not 非
# 一定会得到bool值的结果
print(not True)  # False
print(not 3>4)  # True
print(not 0)  # True
print(not 3)  # False
print(not -3)  # False
print(not None)  # True
print(not "")  # True
print(not " ")  # False

# 数值中,0为假,其他为真
# None为假
# 字符串中, ""为假,其他为真

# 短路操作
# and
# 从左往右依次判断表达式的值是否为True,
#   1. 如果是True,则继续判断后面的表达式,
#   2. 如果为False则直接返回该表达式的值,且后面不会再判断
#   3. 如果判断到最后一个,则不管真假,直接返回最后的数.
a = 10 and None and -2
print(a)  # None

print("-" * 100)  # 重复100次

b = 3 and print(1) and print(3)
print(b)  # None

c = 0 and 3 and "33"  # 0
c = 3 and 4 and 5  # 5
c = 3 and 4 and ""  # ""

print(c)


# or
# 从左往右依次判断表达式的值是否为True,
#   1. 如果是False,则继续判断后面的表达式,
#   2. 如果为True则直接返回该表达式的值,且后面不会再判断
#   3. 如果判断到最后一个,则不管真假,直接返回最后的数.

a = 0 or 3 or 4
print(a)  # 3

b = 0 or None or 4  # 4
b = 0 or 4 or print(5)  # 4
print(b)


# 练习
x = 3 and True  # True
y = 3 or False  # 3
s = x*5 + y
print(s)  # 8


# 练习
# 判断闰年,只要满足下面的2个条件之一则是闰年
#   1.能够被4整除,但是不能被100整除
#   2.能够被400整除
year = 2020
s = (year%4==0 and year%100!=0) or year%400==0
print(s)  # True





