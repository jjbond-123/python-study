


# 关系运算符
#  >, >=, <, <=, ==, !=
print(10 > 3)  # True
print(10 >= 3)  # True
print(10 < 3)  # False
print(10 <= 3)  # False
print(10 == 3)  # False
print(10 != 3)  # True

print(3 == 3)  # True
print(3 == '3')  # False
print(3 != '3')  # True

# 字符串比较
#  ASCII码
#   A~Z: 65~90
#   a~z: 97~122
#   0~9: 48~57
print('a' > 'b')  # False
print('A' > 'a')  # False
print('abcde' < 'acb')  # True
print('ab' < 'abc')  # True
