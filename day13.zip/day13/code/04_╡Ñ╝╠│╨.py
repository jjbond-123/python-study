
# 继承:
#   父类, 基类
#   子类, 派生类


# 男人类
#   属性: name, age, height, qq, wechat, huzi,...
# 女人类
#   属性: name, age, height, qq, wechat, longhair, ...


# 人类(父类)
# object : 超类,根类
#
# class Person(object):
#     def __init__(self):
#         # name, age, height, qq, wechat,
#         pass
#
# # 男人类(子类)
# class Man(Person):
#     def __init__(self):
#         # huzi
#         pass
#
# # 女人类(子类)
# class Women(Person):
#     def __init__(self):
#         # longhair
#         pass


# Ipod, Ipad
# Ipod:
#   属性: 颜色
#   方法: 听音乐
# Ipad:
#   属性: 颜色, 型号
#   方法: 听音乐, 看电影

# 父类: Ipod
class Ipod(object):
    def __init__(self, color):
        print("Ipod.__init__: ", id(self))
        self.color = color

    def listen_music(self):
        print("听音乐")


# 子类: Ipad
class Ipad(Ipod):
    def __init__(self, color, type):
        print("Ipad.__init__:", id(self))
        # 调用父类中的init方法: 通过父类来初始化属性
        # Ipod.__init__(self, color)  # 显式调用
        super().__init__(color)  # 隐式调用

        self.type = type  # 子类自己的属性

    def watch_movie(self):
        print("看电影")

# 对象
# ipod = Ipod("黑色")
# print(ipod.color)
# ipod.listen_music()

# ipadmini = Ipad("土豪金", 'mini')
# print(ipadmini.color)
# print(ipadmini.type)
# ipadmini.listen_music()
# ipadmini.watch_movie()

print()
# Iphone(孙子类)
#   属性: 颜色,类型,价格
#   方法: 听音乐,看电影,打电话
class Iphone(Ipad):
    def __init__(self, color, type, price):
        super().__init__(color, type)
        self.price = price

    def call_phone(self):
        print("打电话")

# 对象
iphone11 = Iphone("黑色", "iphone11", 8888)
print(iphone11.color, iphone11.type, iphone11.price)
iphone11.listen_music()
iphone11.watch_movie()
iphone11.call_phone()

# 多重继承
