

class Cat:
    # 魔术方法: __xx__()
    # 特殊变量: __xx__
    def __init__(self, name, color):
        self.name = name
        self.__color = color

    # # 获取私有属性color
    # def getColor(self):
    #     return self.__color
    #
    # # 设置私有属性color的值
    # def setColor(self, newColor):
    #     self.__color = newColor

    # @property: 作用让函数可以当成属性来使用,相当于get方法, 使用更多
    #   @property:必须有返回值
    # @color.setter: 作用让函数可以当成属性来使用,相当于set方法
    #   @color.setter: 必须有1个参数
    @property
    def color(self):
        return self.__color

    @color.setter
    def color(self, newColor):
        self.__color = newColor

    @property
    def hello(self):
        return "哈哈"

    @hello.setter
    def hello(self, a):
        print(a)

    @property
    def name2(self):
        fullname = self.name + "先生"
        return fullname


# 对象
cat = Cat("加菲猫", "橘色")

print(cat.name)
cat.name = "狸猫"  # 修改属性
print(cat.name)

# 私有属性color
# print(cat.getColor())  # 获取
# cat.setColor('黑色')  # 修改
# print(cat.getColor())  # 获取

print(cat.color)  # 使用@property对应的方法
cat.color = "白色"  # 使用@x.setter对应的方法
print(cat.color)

print(cat.hello)
cat.hello = "嘿嘿"

print(cat.name2)


