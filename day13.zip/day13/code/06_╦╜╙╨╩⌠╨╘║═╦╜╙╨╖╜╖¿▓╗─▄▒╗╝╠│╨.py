

# 私有属性和私有方法不可以继承
class Person:
    def __init__(self, name, age):
        self.name = name
        self.__age = age  # 私有属性

    def f1(self):
        # 类内部的方法可以调用私有属性
        print(self.__age)

    def __f2(self):
        print("f2私有方法")

class Man(Person):
    def __init__(self, name, age):
        super().__init__(name, age)

    def f3(self):
        print(self.name)
        # print(self.__age)  # 报错: 子类中不可以使用父类的私有属性

        self.f1()  # 子类中可以使用父类的成员方法和成员变量(对象属性)
        # self.__f2()  # 报错: 子类中不可以使用父类的私有方法


# 对象
p = Person("老宋", 30)
print(p.name)
# print(p.__age)  # 报错
p.f1()

man = Man("老王", 60)
print(man.name)
man.f3()


