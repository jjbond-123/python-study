
# 限制属性
class Pig:

    # 限制属性只能由name,age
    # __slots__ = ('name', 'age')

    def __init__(self, name, age, sex):
        self.name = name
        self.age = age
        # self.sex = sex  # sex不能使用


# 创建对象: 实例化
p = Pig('八戒', 88, "公")
print(p.name)
print(p.age)
# print(p.sex)

