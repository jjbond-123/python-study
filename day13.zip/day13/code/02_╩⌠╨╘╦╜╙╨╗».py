
# 面向对象
#  特点: 1.封装, 2.继承, 3.多态, 4.抽象

# 1.封装
#  类可以封装属性和方法

#
class A:
    def __init__(self, name, age, sex):
        # 对象属性:成员变量
        self.name = name  # 公有:在类的外部可以访问(对象.属性)
        self.__age = age  # 私有:只能在类内部使用

        self._sex = sex  # 公有,但是不建议这么写

    # 私有方法
    def __get_age(self):
        print(self.__age)

    def get_age2(self):
        print(self.__age)


# 对象
a = A("悟空", 500, '男')
print(a.name)
# print(a.age)  # 报错
# print(a.__age)  # 报错
a.get_age2()  # 间接访问私有属性

print(a._sex)

# print(a._A__age)  # 500, 但是不建议这样写

# a.__get_age()  # 报错
