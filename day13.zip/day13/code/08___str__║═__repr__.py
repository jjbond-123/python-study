

class Dog:
    def __init__(self, name, color):
        self.name = name
        self.color = color

    # __str__
    #   1. 必须返回字符串
    #   2. 作用是让打印对象的结果变成当前函数(__str__)的返回值
    def __str__(self):
        return f'姓名:{self.name}, 颜色:{self.color}'

    # def __repr__(self):
    #     return f'姓名2:{self.name}, 颜色2:{self.color}'


# 对象
dog = Dog("彩彩", "黄色")
print(dog)
# <__main__.Dog object at 0x00000144C53C9908>

# print(repr(dog))
