''''''

# 利用面向对象的思想写下面的程序：直接赋值
# 1.小美在朝阳公园溜旺财【注：旺财是狗】
import math


class Person:
    def __init__(self, name):
        self.name = name

    def play_dog(self, place):
        print(self.name, "在", place, "溜旺财")


xiaomei = Person("小美")
xiaomei.play_dog("朝阳公园")


# 2.小明穿着白色的特步运动鞋在奥林匹克公园跑步
class Person2:
    def __init__(self, name, shoes):
        self.name = name
        self.shoes = shoes

    def run(self, place):
        print(f"{self.name}穿着{self.shoes}在{place}跑步")


xiaoming = Person2("小明", "白色的特步运动鞋")
xiaoming.run("奥林匹克公园")


# 3.赵老师在讲台上讲课，小刚认真的听课做笔记
class Teacher:
    def __init__(self, name):
        self.name = name

    def teach(self):
        print(f'{self.name}在讲台上讲课')

class Student:
    def __init__(self, name):
        self.name = name

    def listen(self, teacher):
        print(f'{self.name}认真听{teacher.name}的课做笔记')

teacher_zhao = Teacher("赵老师")
xiaogang = Student("小刚")
teacher_zhao.teach()
xiaogang.listen(teacher_zhao)


# 4.张阿姨和李阿姨在物美超市买红富士
# 提示: 写一个阿姨类,创建2个阿姨对象
class Aunt:
    def __init__(self, name):
        self.name = name

    def buy(self, goods):
        print(f"{self.name}在物美超市买{goods}")

aunt_zhang = Aunt("张阿姨")
aunt_li = Aunt("李阿姨")
aunt_zhang.buy("红富士")
aunt_li.buy("红富士")


# 使用构造函数的方式写下面的程序
# 1.定义一“圆”（Circle）类，圆心为“点”Point类，构造一圆，求圆的周长和面积，并判断某点与圆的关系
# 圆:
#   属性: 半径,圆心
#   方法: 周长,面积
# 点:
#   属性: x,y

# 圆
class Circle:
    def __init__(self, r, p):
        self.r = r
        self.p = p

    def zhouchang(self):
        return 2 * self.r * 3.14

    def area(self):
        return self.r**2 * 3.14


# 点
class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def relation_circle(self, circle):
        a = self.x - circle.p.x
        b = self.y - circle.p.y
        c = math.sqrt(a*a + b*b)

        if c > circle.r:
            print("在圆外")
        elif c < circle.r:
            print("在圆内")
        else:
            print("在圆上")


# 对象
c = Circle(5, Point(3, 4))
p = Point(6, 8)

p.relation_circle(c)


# 2.李晓在家里开party，向朋友介绍家中的黄色的宠物狗【彩彩】具有两条腿走路的特异功能。
class Person22:
    def __init__(self, name, dog):
        self.name = name
        self.dog = dog

    def party(self, place):
        print(f'{self.name}在{place}开party')

    def introduce(self):
        print(f'向朋友介绍家中的{self.dog.color}的宠物狗【{self.dog.name}】具有{self.dog.walk()}')


class Dog:
    def __init__(self, name, color):
        self.name = name
        self.color = color

    def walk(self):
        return "两条腿走路的特异功能"

caicai = Dog("彩彩", "黄色")
lixiao = Person22("李晓", caicai)
lixiao.party("家里")
lixiao.introduce()


# 3.王梅家的荷兰宠物猪【笨笨】跑丢了，她哭着贴寻猪启示。
class Person33:
    def __init__(self, name, pig):
        self.name = name
        self.pig = pig

    def find_pig(self):
        print(f'{self.name}家的{self.pig.place}宠物猪【{self.pig.name}】{self.pig.run()}，她哭着贴寻猪启示。')

class Pig:
    def __init__(self, name, place):
        self.name = name
        self.place = place

    def run(self):
        return "跑丢了"


benben = Pig("笨笨", "荷兰")
wangmei = Person33("王梅", benben)
wangmei.find_pig()


# 4.富二代张三向女朋友李四介绍自己的新跑车：白色的宾利
class Rich2:
    def __init__(self, name, girl_friend, car):
        self.name = name
        self.girl_friend = girl_friend
        self.car = car

    def introduce(self):
        print(f'富二代{self.name}向女朋友{self.girl_friend}介绍自己的新跑车：{self.car}')


wangsicong = Rich2("王思聪", "杨幂", "白色的宾利")
wangsicong.introduce()
