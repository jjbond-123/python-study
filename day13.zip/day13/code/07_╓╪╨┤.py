
# 重写: 子类有和父类同名的方法

class Person:
    def __init__(self, name):
        self.name = name

    def sleep(self):
        print(self.name, "睡8个小时")


class Man(Person):
    def __init__(self, name):
        super().__init__(name)

    # 重写了父类的sleep方法
    def sleep(self):
        print(self.name, "睡4个小时")


# 对象
p = Person("张三")
p.sleep()

luozhixiang = Man("罗志祥")
luozhixiang.sleep()




