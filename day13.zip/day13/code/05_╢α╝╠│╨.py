
# 多继承: 一个子类同时继承多个父类

# Father
class Father(object):
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def work(self):
        print("会工作赚钱")


# Mother
class Mother(object):
    def __init__(self, height, face_value):
        self.height = height
        self.face_value = face_value

    def cook(self):
        print("会做饭")


# Son
class Son(Father, Mother):
    def __init__(self, name, age, height, face_value, girl_friend):
        # 显式调用
        Father.__init__(self, name, age)
        Mother.__init__(self, height, face_value)

        # 隐式调用
        # # super().__init__(name, age)
        # super(Son, self).__init__(name, age)
        # super(Father, self).__init__(height, face_value)

        self.girl_friend = girl_friend

    def play(self):
        print("玩游戏")


# 对象
nezha = Son("哪吒", 10, 120, 100, "女朋友")
print(nezha.name, nezha.age, nezha.height, nezha.face_value, nezha.girl_friend)
nezha.work()
nezha.cook()
nezha.play()

print(Son.__mro__)  # mro算法: 按顺序从左往右依次继承
# (<class '__main__.Son'>, <class '__main__.Father'>, <class '__main__.Mother'>, <class 'object'>)
