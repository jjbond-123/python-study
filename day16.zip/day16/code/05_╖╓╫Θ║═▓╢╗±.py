

# {} : 表示前面字符的数量
# [] : 表示单个字符的范围
# () : 表示整体,还可以表示分组
import re

s = "0755-88888888"
pattern = '(\d{4})-(\d{8})'

# 使用search
res = re.search(pattern, s)
print(res)
print(res.group())  # '0755-88888888'
print(res.group(0))  # '0755-88888888'
print(res.group(1))  # '0755' , 第一个分组(第一个括号)的内容
print(res.group(2))  # '88888888', 第二个分组(第二个括号)的内容

print(res.groups())  # ('0755', '88888888'), 获取所有分组

# 使用findall (重点掌握)
res = re.findall(pattern, s)  # [('0755', '88888888')]
print(res)

#
s = "珠宝店店主称这个创意是受一名顾客的启发，当时这名顾客要在家中举办婚礼，希望在店内定制新娘和新郎的专属口罩。店主表示这些口罩的布料材质遵从了政府生产防护用品的指导意见。这些钻石口罩依据用料的不同价格在15万到40万卢比（约1.4万—3.7万人民币）之间。镶嵌的钻饰和金饰可以按照顾客需求拆下制作别的饰品。"

pattern = r'(\d+)万到(\d+)万卢比'
res = re.findall(pattern, s)
print(res)

# 使用别名: 给分组加名字
pattern = r'(?P<start>\d+)万到(?P<end>\d+)万卢比'
res = re.search(pattern, s)
print(res.group("end"))  # 40
print(res.group("start"))  # 15


# 编译正则: 创建一个正则表达式对象
# 效率更高
pattern = re.compile(r'(\d+)万到(\d+)万卢比')
res = pattern.findall(s)
print(res)


# 扩展: 非捕获性分组
pattern = r'(\d+)万到(?:\d+)万卢比'
res = re.findall(pattern, s)
print(res)  # ['15']





