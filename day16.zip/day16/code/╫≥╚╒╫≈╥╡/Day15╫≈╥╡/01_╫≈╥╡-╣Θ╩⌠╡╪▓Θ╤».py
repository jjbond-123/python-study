
#
# 题目：创建函数， 从文件guishudi.txt中获取数据，输入完整手机号11位，匹配前7位，输出对应的地址和卡类型
#
# 60268|1340475|0431|吉林省长春市|吉林移动大众卡
#   手机号前7位 ：1340475


def fn(phone):
    phone = str(phone)[:7]

    fp = open('guishudi.txt', 'r', encoding='utf-8')

    list1 = fp.readlines()
    for row in list1:
        list2 = row.split("|")
        if list2[1] == phone:
            print(list2[-2], list2[-1])

    fp.close()

fn(15815840000)







