
#
# 题目： 邮编查询
# 	创建函数， 传入一个邮编，得到归属地
#
#   [370601,"山东省烟台市市辖区"],


def fn(post_code):
    with open('youbian.txt', 'r', encoding='utf-8') as fp:
        list1 = fp.readlines()

        for row in list1:
            list2 = eval(row[:-2])
            if list2[0] == post_code:
                print(list2[1])

fn(440306)

