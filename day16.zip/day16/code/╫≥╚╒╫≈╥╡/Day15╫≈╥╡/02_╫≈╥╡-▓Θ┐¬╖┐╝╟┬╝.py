
#
# 题目： 开房查询
# 	创建函数，传入一个名字，查找到这哥们所有的开房记录，
#            然后写入到以这哥们名字为名的txt文件中 如：张三.txt
#

def fn(name):
    with open('kaifanglist.txt', encoding='utf-8') as fp:
        list1 = fp.readlines()

        with open(f'{name}.txt', 'a', encoding='utf-8') as fp2:

            for row in list1:
                if row.startswith(name):
                        fp2.write(row)
                        fp2.flush()  # 清空临时缓存


fn("薛小姐")

