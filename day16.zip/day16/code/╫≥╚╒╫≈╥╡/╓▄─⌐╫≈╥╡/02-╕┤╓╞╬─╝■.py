

# 1、拷贝文件【考虑大文件拷贝，每次读取1024字节拷贝】
import os


def copy_file(src_path):
    # 读取源文件内容
    fp1 = open(src_path, 'rb')
    content1 = fp1.read()

    # 写入副本文件
    dst_path = get_copyfilename(src_path)
    fp2 = open(dst_path, 'wb')
    fp2.write(content1)

    fp1.close()
    fp2.close()


# 获取某文件的副本文件名
def get_copyfilename(src_path):
    src_list = os.path.split(src_path)
    filename = src_list[1]  # 'a.pdf'
    index = filename.rfind('.')  # 点的下标位置
    filename2 = filename[:index]  # 文件名
    extendname2 = filename[index:]  # 扩展名
    dst_path = filename2 + "_副本" + extendname2
    return dst_path


# 考虑大文件
def copy_file2(src_path):
    # 读取源文件内容
    fp1 = open(src_path, 'rb')
    # 写入副本文件
    dst_path = get_copyfilename(src_path)
    fp2 = open(dst_path, 'wb')

    while True:
        content1 = fp1.read(1024)
        if not content1:  # 如果读取完了
            break

        fp2.write(content1)
        fp2.flush()

    fp1.close()
    fp2.close()


src = r'C:\Users\ijeff\Desktop\Python2003\day16\code\昨日作业\周末作业\a.pdf'
# copy_file(src)
copy_file2(src)






