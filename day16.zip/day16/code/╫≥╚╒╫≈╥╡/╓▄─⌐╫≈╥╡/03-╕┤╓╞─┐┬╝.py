
# 复制目录（考虑拷贝所有子文件）
import os

def copyPath(sourcePath, targetPath):

    # 判断原目录是否存在
    if not os.path.exists(sourcePath):
        return "目录不存在"
    # 判断目标目录是否存在，如果不存在则创建
    if not os.path.exists(targetPath):
        os.mkdir(targetPath)

    # 提示：
    # 遍历sourcePath下的所有子目录和子文件
    #   1， 如果是子文件，则复制文件
    #   2， 如果是子目录，在目标目录创建相同的目录名称，递归调用
    #  注意：子文件或子目录的绝对路径

    filename_list = os.listdir(sourcePath)
    for filename in filename_list:
        file_path = os.path.join(sourcePath, filename)  # 原来目录
        file_path2 = os.path.join(targetPath, filename)  # 目标目录

        # 如果是文件,则拷贝
        if os.path.isfile(file_path):
            copy_file2(file_path, file_path2)
        # 如果是目录,则递归遍历
        else:
            # 递归
            copyPath(file_path, file_path2)


# 考虑大文件
def copy_file2(src_path, dst_path):
    fp1 = open(src_path, 'rb')
    fp2 = open(dst_path, 'wb')

    while True:
        content1 = fp1.read(1024)
        if not content1:  # 如果读取完了
            break

        fp2.write(content1)
        fp2.flush()

    fp1.close()
    fp2.close()


if __name__ == "__main__":
    # 将sourcePath目录的所有内容拷贝到targetPath目录下
    sourcePath = r"C:\Users\ijeff\Desktop\Python2003\day15"
    targetPath = r"C:\Users\ijeff\Desktop\Python2003\day16\code\day15_2"
    copyPath(sourcePath, targetPath)