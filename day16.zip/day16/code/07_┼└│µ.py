

# 网址
import re

url = "https://search.51job.com/list/040000,000000,0000,00,9,99,python,2,1.html?lang=c&stype=&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&providesalary=99&lonlat=0%2C0&radius=-1&ord_field=0&confirmdate=9&fromType=&dibiaoid=0&address=&line=&specialarea=00&from=&welfare="

# 模拟浏览器
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36"
}

# 1. 获取网页内容
import requests

response = requests.get(url, headers=headers)
content = response.content.decode('GBK')
# print(content)  # 网站内容


# 正则
# pattern = r'"rt">(.*)</div>'  # 贪婪的, 会匹配到最后一个</div>
pattern = r'"rt">(.*?)</div>'  # 非贪婪的, 会匹配到最近一个</div>

# 有换行,需要加上re.S
res = re.findall(pattern, content, re.S)
# print(res)
print(res[0])


# 获取职位名
pattern2 = r'"el">(.*?)"el">'
job_list = re.findall(pattern2, content, re.S)
# print(job_list)

for job in job_list:
    # print(job)
    pattern3 = r'title="(.*?)"'
    job_name = re.findall(pattern3, job)
    print(job_name[0], job_name[1])



