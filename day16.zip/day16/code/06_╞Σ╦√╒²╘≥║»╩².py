
# 其他正则函数: 了解即可
import re

# finditer: 了解
res = re.finditer(r'\d+', "123abc456def678")
print(res)  # iterator迭代器

for i in res:
    # print(i)
    print(i.group(), i.span())


# re.split: 分割,拆分
s = "hello world"
print(re.split(r'l|o', s))
# ['he', '', '', ' w', 'r', 'd']

# | 表示或者

# 替换
s = "today is good day today is a nice day"
print( re.sub(r'\s', '-', s) )
# today-is-good-day-today-is-a-nice-day
print( re.subn(r'\s', '-', s) )
# ('today-is-good-day-today-is-a-nice-day', 8)



