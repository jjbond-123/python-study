

# 正则表达式: Regular Expression
# 作用: 匹配有规则的字符串

import re

# 第一个方法: 了解
# re.match(): 匹配字符串是否以指定正则表达式开头
res = re.match('\d+', "123456")  # object
res = re.match('goog', "google")  # object
res = re.match('oog', "google")  # None
print(res)


# 第二个方法
# re.search(): 匹配字符串中是否包含正则表达式
res2 = re.search('oog', 'google')  # object
res2 = re.search('abc', 'google')  # None
res2 = re.search('GOO', 'google', re.I)  # object
print(res2)

# re.I : ignore 忽略大小写

# 第三个方法
# re.findall() : 获取所有匹配的子字符串, 返回的是列表
res3 = re.findall('goo', 'google')  # ['goo']
res3 = re.findall('goo', 'google google google')  # ['goo', 'goo', 'goo']
res3 = re.findall('abc', 'google')  # []
print(res3)


