

# 符号

import re

# 1. 匹配单个字符
# . 表示匹配任意单个字符, 除了换行\n
print( re.search('go.gle', 'go9gle') )
print( re.search('go.gle', 'go\ngle') )  # None
print( re.search('go.gle', 'go\ngle', re.S) )

# re.S : 让.可以匹配\n

# [] : 表示匹配单个字符的范围
# [abc]: 匹配a或b或c
# [a-z] : 匹配小写字母
# [A-Z] : 匹配大写字母
# [a-zA-Z] : 匹配字母
# [a-zA-Z0-9_] : 匹配数字字母下划线
print( re.search('go[abc]gle', 'gobgle') )
print( re.search('go[a-z]gle', 'goggle') )
print( re.search('go[a-zA-Z0-9_]gle', 'go_gle') )

# \d : 表示数字,等价于[0-9]
# \D : 表示非数字,等价于[^0-9]
# \w : 表示数字字母下划线,等价于[a-zA-Z0-9_]
# \W : 表示非数字字母下划线,等价于[^a-zA-Z0-9_]
# \s : 表示空格 或 换行\n 或 制表符\t 或 换页符\f 或 回车符\r
# \S : 表示非空格
print( re.search('go\dgle', 'go9gle') )
print( re.search('go\Dgle', 'go,gle') )

print( re.search('go\wgle', 'go9gle') )
print( re.search('go\Wgle', 'go9gle') )

print( re.search('go\sgle', 'go gle') )
print( re.search('go\Sgle', 'go9gle') )


# 单个字符需要重点掌握:
#   .  []  \d \w \s

