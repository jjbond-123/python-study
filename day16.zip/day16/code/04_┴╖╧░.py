import re

# 匹配中文
chinesePattern = "[\u4e00-\u9fa5]+"
print( re.search(chinesePattern, "你好") )

# 匹配手机号(1开头, 长度11位)
print( re.search('^1\d{10}$', "13677778888") )


# 匹配qq号： 5-11位, 第一位不能为0
print( re.search('^[1-9]\d{4,10}$', "610567895") )


# 匹配任意一个邮箱   如：jack@163.com，11@qq.com, aaa@sina.com.cn
print( re.search('^\w+@\w+(\.\w+){1,2}$', "610567895@qq.com") )


# 匹配身份证: 18位，最后一位可能是X
# 或 |
print( re.search('^\d{17}(X|\d)$', "44332319991122334X") )


# 邮政编码(共6位数字, 第一位不能为0)
print( re.search('^[1-9]\d{5}$', "443323") )


# 用户名(只能使用数字字母下划线, 且数字不能开头, 长度在6-15位)
print( re.search('^[a-zA-Z_]\w{5,14}$', "hello123") )

