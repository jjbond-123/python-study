
# 2. 表示数量的符号
# 重点掌握
# 表示数量: ?  +  *   {}
# 表示边界: ^  $  ^$


import re

# ? : 表示前面的字符可以出现0次或1次
# + : 表示前面的字符可以出现1次或多次
# * : 表示前面的字符可以出现0次或多次

print( re.findall('go?gle', 'gogle') )   # 非贪婪(最多匹配一个)
print( re.findall('go+gle', 'goooogle') )  # 贪婪(尽量多的匹配)
print( re.findall('go*gle', 'goooogle') )  # 贪婪

print( re.findall('g.*gle', 'g123abc,.;lAoogle') )

# {} : 表示前面字符出现的次数范围
# {3} : 表示3次
# {2,5} : 表示2次~5次之间
# {,5} : 表示最多5次
# {2,} : 表示至少2次
print( re.findall('go{3}gle', 'gooogle') )
print( re.findall('go{2,5}gle', 'goooogle') )  # 贪婪
print( re.findall('go{,5}gle', 'google') )
print( re.findall('go{2,}gle', 'goooooogle') )


# 3. 边界符号
# ^ : 开头匹配
# $ : 结尾匹配
# ^$ : 完全匹配, 除了正则中的字符串以外,不可以有其他多余的字符
print( re.search('^google', 'google123') )
print( re.search('google$', '123google') )
print( re.search('^google$', 'googlegoogle') )  # None
print( re.search('^go+gle$', 'goooooooooogle') )

print( re.search('go+gle', '123goooooooooogleabc') )  # 只要包含正则的内容即可,两边可以有其他多余字符


# 了解其他的边界符号
# \A : 开头匹配
# \Z : 结尾匹配
# \A \Z : 完全匹配, 除了正则中的字符串以外,不可以有其他多余的字符
print( re.search('\Agoogle', 'google123') )
print( re.search('google\Z', '123google') )
print( re.search('\Agoogle\Z', 'google') )

print( re.findall('^#', "#google\n#baidu\n#360", re.M) )  # ['#', '#', '#']
print( re.findall('\A#', "#google\n#baidu\n#360", re.M) )  # ['#']

# re.M: 换行模式(了解)

# \b, \B
print( re.search(r'google\b', "google123 123google") )  # 是以google结尾的单词
print( re.search(r'google\B', "google123 123google") )  # 不是以google结尾的单词


