
import csv

# 读取
def read_csv(path):
    #
    fp = open(path, "r", encoding='utf-8')
    # print(fp.read())

    # csv模块
    reader = csv.reader(fp)
    for row in reader:
        print(row)

    fp.close()

# 写入
def write_csv(path):

    fp = open(path, 'a', encoding='utf-8', newline='')

    # csv模块
    writer = csv.writer(fp)
    writer.writerow(['zhangsan', '1111', '22', 'china'])

    fp.close()


if __name__ == '__main__':
    # read_csv('text.csv')
    write_csv('text.csv')

