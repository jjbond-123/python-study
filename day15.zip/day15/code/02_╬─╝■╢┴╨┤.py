
# 文件操作
#   1. 打开文件
#   2. 进行文件操作(读read, 写write)
#   3. 关闭文件


# 1. 打开文件
# 默认encoding是: GBK
fp = open("hello.txt", 'r', encoding="utf-8")

# 2. 读取文件
# read
print(fp.read())

# 3. 关闭文件
fp.close()


# 文件模式
# mode: 打开方式
#   r: 只读, 文件不存在则报错
#   rb: 只读,读二进制, 文件不存在则报错
##   r+: 可读写, 了解, 建议不用
##   rb+: 可读写,读写二进制, 了解, 建议不用

#   w: 清空写
#   w: 只写, 文件不存在则自动创建
#   wb: 只写,写二进制, 文件不存在则自动创建

#   a: 追加写
#   a: 追加写, 文件不存在则自动创建
#   ab: 追加写,写二进制, 文件不存在则自动创建

# r
# fp: 文件句柄对象
# r
# fp = open('hello.txt', 'r', encoding='utf-8')

# print(fp.read())  # 读取文件的所有内容

# print(fp.read(5))  # 读取5个字符
# print(fp.read(5))  # 读取5个字符

# print(fp.readline())  # 读取一行
# print(fp.readline())  # 读取一行

# print(fp.readlines())  # 读取所有行组成的列表
# ['hellon你好hellon你好hellon你好\n', 'hellon你好1\n', 'hellon你好2\n', 'hellon你好3\n']

# fp.close()


# rb
# fp = open('hello.txt', 'rb')
# # print(fp.read())  # 二进制
# print(fp.read().decode())  # 字符串
# fp.close()

# w : 清空写
# fp = open("hello2.txt", 'w', encoding='utf-8')
# fp.write("哈哈")
# fp.close()

# # wb: 清空写,二进制
# fp = open("hello.txt", 'wb')
# fp.write("嘿嘿".encode())
# fp.close()

# a : 追加写
# fp = open("hello.txt", 'a', encoding='utf-8')
# fp.write("哈哈")
# fp.close()

# ab : 追加写二进制
fp = open("hello.txt", 'ab')
fp.write("哈哈".encode())
# fp.flush()  # 清空缓冲区
fp.close()


# 如果文件不存在,防止读取时报错
try:
    fp2 = open('a.txt', 'r', encoding='utf-8')
    content = fp2.read()
    print(content)

except Exception as e:
    print("文件操作读取错误:", e)

else:
    fp2.close()


# 可以使用with关键字
#   作用: 自动关闭文件,即使是在出现异常的情况下也会关闭
# with open('hello4.txt', 'r', encoding='utf-8') as fp:
#     content = fp.read()
#     print(content)



# with open('5.png', 'rb') as fp:
#     with open('6.png', 'wb') as fp2:
#         fp2.write(fp.read())
#










