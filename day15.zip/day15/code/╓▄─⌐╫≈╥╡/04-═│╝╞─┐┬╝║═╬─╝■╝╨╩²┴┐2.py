
# 1、使用函数递归，分别统计文件夹newdir中文件和文件夹的个数
#    提示：统计当前目录下的文件数量和文件夹数量
#         如果碰到文件，则文件数量+1
#         如果碰到文件夹，则文件夹数量+1，递归调用fn()并传入当前子文件夹目录，

import os

file_count = 0
dir_count = 0

def fn(path):
    if not os.path.exists(path):
        return

    filename_list = os.listdir(path)

    # 遍历并删除里面的文件和目录
    for filename in filename_list:
        file_path = os.path.join(path, filename)
        # 文件
        if os.path.isfile(file_path):
            global file_count
            file_count += 1

        # 目录
        elif os.path.isdir(file_path):
            global dir_count
            dir_count += 1

            # 递归
            fn(file_path)


def fn2(path):
    file_count2 = 0
    dir_count2 = 0

    if not os.path.exists(path):
        return

    filename_list = os.listdir(path)

    # 遍历并删除里面的文件和目录
    for filename in filename_list:
        file_path = os.path.join(path, filename)
        # 文件
        if os.path.isfile(file_path):
            file_count2 += 1
        # 目录
        elif os.path.isdir(file_path):
            dir_count2 += 1

            # 递归
            f_count, d_count = fn2(file_path)
            file_count2 += f_count
            dir_count2 += d_count

    return file_count2, dir_count2


if __name__ == '__main__':
    # fn(r'C:\Users\ijeff\Desktop\Python2003\day15\code\周末作业\newdir')
    # print(file_count, dir_count)

    a, b = fn2(r'C:\Users\ijeff\Desktop\Python2003\day15\code\周末作业\newdir')
    print(a, b)

# def m():
#     return 1, 2
#
# a, b = m()
# print(a, b)  # 1 2



