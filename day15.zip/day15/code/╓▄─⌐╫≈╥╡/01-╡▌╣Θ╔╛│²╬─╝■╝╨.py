''''''

# 递归删除文件夹(可能包含子文件或子文件夹)
# 【温馨提示：创建一个文件夹，不要直接操作已有的文件夹】

# 提示：要先将文件夹中的所有子文件删除再删除本文件夹
# remove(): 删除文件
# rmdir()： 删除空目录

import os

def fn(path):
    if not os.path.exists(path):
        return

    filename_list = os.listdir(path)

    # 遍历并删除里面的文件和目录
    for filename in filename_list:
        file_path = os.path.join(path, filename)
        # 文件
        if os.path.isfile(file_path):
            os.remove(file_path)
        # 目录
        elif os.path.isdir(file_path):
            # 递归
            fn(file_path)

    # 删除空目录
    os.rmdir(path)


if __name__ == '__main__':
    fn(r'C:\Users\ijeff\Desktop\Python2003\day15\code\周末作业\newdir')

# 调试
# 断点