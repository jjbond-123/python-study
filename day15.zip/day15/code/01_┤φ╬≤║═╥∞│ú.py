

# 错误: error
# 异常: exception 写的时候代码不报错,但是运行可能出错


# 异常:
#   1. 一旦出错,则后面的代码无法执行
#   2. 需要捕获异常, 可以让后面的代码正常执行

def f1(n):
    # 报错
    # print(10/n)
    # ZeroDivisionError: division by zero

    # 捕获异常
    # try-except
    # try: 尝试执行某段代码
    # except: 如果在try中代码出现错误,则会进入except

    try:
        print(10/n)
    except:
        print("不好意思, 报错了")


# f1(0)

'''
NameError: 变量未被定义
TypeError: 类型错误
IndexError: 索引异常
keyError: 字典的key错误
ValueError: 值错误
AttributeError: 属性异常
ImportError: 导入模块的时候路径异常
SyntaxError: 语法错误, 代码不能编译
'''

# a += 1
# 捕获指定的错误,并得到错误内容
try:
    a += 1
except TypeError as e:
    print(e)
except NameError as e:
    print(e)  # name 'a' is not defined

# 捕获所有错误,并得到错误内容
# Exception是异常的父类
# BaseException 是 Exception的父类
try:
    a = 1/0
except Exception as e:
    print(e)  # division by zero
    print(type(e))  # <class 'ZeroDivisionError'>


# try-except-else
try:
    a = [1,2,3]
    b = a[2]
except BaseException as e:
    print("出现错误:", e)

else:
    print("没有错误")

# try-except-finally
try:
    a = [1]
    b = a[2]
except BaseException as e:
    print("出现错误:", e)

finally:
    print("不管有没有错, 我都会执行")

print("end")


# 抛出异常
# raise
# raise NameError("这是我主动抛出的异常")

# 自定义异常
class MyException(Exception):
    def __init__(self, msg):
        self.msg = msg

try:
    raise MyException("自定义异常")
except Exception as e:
    print(e)
    print(type(e))  # <class '__main__.MyException'>


# 断言
# assert : 预测
def f2(n):

    # 预测n!=0, 如果跟我的预测不一致,则抛出异常,右边的字符串是错误提示
    assert n!=0, "n不能为0"
    # AssertionError: n不能为0

    a = 10/n


f2(0)





