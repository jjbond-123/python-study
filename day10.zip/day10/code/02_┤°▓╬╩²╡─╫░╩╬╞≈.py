

# 带普通参数
def outer1(f):
    def inner(a):
        f(a)
    return inner

@outer1
def sing(song):
    print("韩红唱:", song)

# print(sing.__name__)  # inner
sing("青藏高原")


# 通用装饰器
#   通用:指的是通用参数
def outer2(f):
    def inner(*args, **kwargs):
        # args = ("贾玲", "老女孩")
        print("开始唱歌了...")
        r = f(*args, **kwargs)
        print("唱完了!", r)

        return r

    return inner

@outer2
def sing2(singer, song, a):
    print(singer, "唱:", song, a)
    return "Nice"

result = sing2("贾玲", "老女孩", a=10)
print(result)


print()
# 扩展
# *,**
# 1. 如果写在函数声明(写成形参): 作用是声明该参数可以接收多个参数
# 2. 写在其他地方则是将元组或者列表或者字典展开.
def fn(*args):
    print(args)

l = [1,2,3]
fn(l)  # ([1, 2, 3],)
fn(*l)  # (1, 2, 3)
# fn(*l) 相当于: fn(1,2,3)

def fn2(**kwargs):
    print(kwargs)

d = {'name': '宝强', 'sex': 'male'}
fn2(d=d)  # {'d': {'name': '宝强', 'sex': 'male'}}
fn2(**d)  # {'name': '宝强', 'sex': 'male'}
# fn2(**d) 相当于 fn2(name='宝强', sex='male')


# 多个装饰器修饰同一个函数
def outer3(f):
    def inner():
        print(1)
        f()
        print(2)
    return inner


def outer4(f):
    def inner():
        print(3)
        f()
        print(4)
    return inner


@outer3
@outer4
def h():
    print("罗志祥睡得少")


h()







