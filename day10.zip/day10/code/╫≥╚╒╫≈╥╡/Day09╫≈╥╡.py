

# 1.简述必需参数、关键字参数、默认参数、不定长参数的区别
# def fn(a, b, *args, c=4, d=6, **kwargs):
#   pass
# fn(1, 2, 3, 4, d=5, c=5)
#
# 必需参数: 或者叫位置参数, 参数有顺序, 形参和实参数量必需一致, 必需传值
# 关键字参数: 存在于实参中, 参数可以没有顺序, 一般和默认参数结合使用
# 默认参数: 存在于形参中, 可以不给值,会使用默认值,如果给值则使用你给的值
# 不定长参数:
#   *args : 存在于形参中, 为了接收任意多个(0~n)位置参数, 会得到一个元组.
#   **kwargs : 存在于形参中, 为了接收任意多个(0~n)关键字参数, 会得到一个字典.


# 2.写函数，计算传入字符串中单个【数字】、【字母】、【空格] 以及 【其他字符】的个数

def fn2(s):
    #
    count1 = 0
    count2 = 0
    count3 = 0
    count4 = 0

    for c in s:
        if c.isdigit():
            count1 += 1
        elif c.isalpha():
            count2 += 1
        elif c.isspace():
            count3 += 1
        else:
            count4 += 1

    print(count1, count2, count3, count4)


s2 = "hellodfasdf34234,.,.A    S FD"
fn2(s2)


# 3.写函数，判断用户传入的参数（字符串、列表、元组其中之一）长度是否大于5
def fn3(s):
    return len(s)>5
    # if len(s) > 5:
    #     return True
    # return False

fn3([1,2,3,4,5,6])


# 4.写函数，检查用户传入的对象（字符串、列表、元组其中之一）的每一个元素是否都是空内容("", " ", None)。
# ['    ', '', ' ', None]
def fn4(s):
    # for c in s:
    #     n = ['', ' ', None]
    #     if c in n or c.isspace():
    #         return True
    # return False

    for c in s:
        if c==None or c=="" or str(c).isspace():
            pass
        else:
            return False

    return True


print( fn4([' ',None, "    "]) )


# 5.写一个函数，识别字符串是否符合python语法的变量名
#   数字字母下划线，且不能以数字开头，不能使用关键字
# import keyword
# keyword.kwlist

import keyword

def fn5(name=''):
    # 判断是否是数字
    if name[0].isdigit():
        return False

    # 判断是否是关键字
    if name in keyword.kwlist:
        return False

    # 判断数字字母下划线
    for c in name:
        if c.isalnum() or c=="_":
            pass
        else:
            return False

    return True


print( fn5("str") )


# 6.定义一个函数，传入不定个数的数字，返回所有数字的和, 提示: *args
def fn6(*args):
    return sum(args)

print( fn6(1,2,3,4) )


# 7, 写一个函数计算1到n的和, 并返回结果打印出来;(n为函数参数)
def fn7(n):
    return sum(range(1, n+1))

print( fn7(4) )


# 8, 写一个函数计算n的阶乘,并返回结果打印出来
import math
def fn8(n):
    return math.factorial(n)

print( fn8(5) )


# 9, 写一个函数计算两个数的最小公倍数; 并返回结果打印出来
def fn9(a, b):
    max1 = max(a, b)
    for i in range(max1, a*b+1):
        if i%a==0 and i%b==0:
            return i

print( fn9(6, 9) )


# 10, 写一个函数判断一个年份是不是闰年
def is_leap(y):
    return (y%4==0 and y%100!=0) or y%400==0

print( is_leap(2020) )


# 11, 年月日分别为自定义函数的参数，判断某一个日期是否为合法的日期;
# 	    如: 2018年12月33日不是合法的日期
# 	        2018年11月13日是合法的日期
# 提示: def fn(year, month, day):


def fn11(year, month, day):
    if month<1 or month>12:
        return False

    # days: 每个月的总天数
    days = 31
    if month in [4,6,9,11]:
        days = 30
    elif month == 2:
        if is_leap(year):
            days = 29
        else:
            days = 28

    # 判断天是否合法
    if day<1 or day>days:
        return False

    return True


print( fn11(2019, 2, 29) )


