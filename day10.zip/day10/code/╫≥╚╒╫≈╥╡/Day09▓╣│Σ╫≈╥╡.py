

# b.判断闰年
def is_leap(y):
    return y%4==0 and y%100!=0 or y%400==0


# c.判断月的天数
def get_month_days(y, m):
    days = 31
    if m in [4,6,9,11]:
        days = 30
    elif m == 2:
        if is_leap(y):
            days = 29
        else:
            days = 28
    return days


# d. 距离1900年1月1日的总天数
def get_year_days(y):
    s = 0
    for i in range(1900, y):
        if is_leap(i):
            s += 366
        else:
            s += 365
    return s


# e.当月距离当年的1月1日多少天
def get_year_month_days(y, m):
    s = 0
    for i in range(1, m):
        s += get_month_days(y, i)
    return s


# f. 将d和e的结果相加, 求出总天数
def get_days(y, m):
    return get_year_days(y) + get_year_month_days(y, m)


# g. 求当前月的1日是星期几
# 1900年1月1日是万年历的起点,是星期一
def get_week(y, m):
    return (get_days(y, m)+1) % 7


# h. 格式化输出日历
def print_calendar(y, m):
    week = get_week(y, m)
    print(week)

    print("星期日\t星期一\t星期二\t星期三\t星期四\t星期五\t星期六")

    # 打印空格
    for i in range(week):
        print(" ", end='\t\t ')

    # 打印day
    days = get_month_days(y, m)  # 当前月的总天数
    for i in range(1, days+1):
        print(i, end='\t\t ')

        # 控制每7个一行,week等于空格数
        if (week+i) % 7 == 0:
            print()


# a.输入年,月
year = int(input("输入年:"))
month = int(input("输入月:"))

print_calendar(year, month)









