
# 栈: 一种数据结构
#  特点: 先进后出, 后进先出

# 列表可以实现栈结构
# 控制只在一端(列表末尾)插入append和取出pop

# 创建栈(列表)
stack = []

# 入栈
stack.append('A')
print(stack)

stack.append('B')
print(stack)

stack.append('C')
print(stack)

stack.append('D')
print(stack)


# 出栈
stack.pop()
print(stack)

stack.pop()
print(stack)

stack.pop()
print(stack)

stack.pop()
print(stack)









