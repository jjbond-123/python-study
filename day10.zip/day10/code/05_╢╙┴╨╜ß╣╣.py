
# 队列: 一种数据结构
#   特点: 先进先出,后进后出
#   排队

import collections


# 创建队列
queue = collections.deque()
print(queue)  # deque([])


# 入队列
queue.append('A')  # 从队列的右边加入一个数据
print(queue)

queue.append('B')
print(queue)

queue.append('C')
print(queue)

queue.append('D')
print(queue)


# 出队列
queue.popleft()  # 从左边取出一个数据
print(queue)

queue.popleft()
print(queue)

queue.popleft()
print(queue)

queue.popleft()
print(queue)






