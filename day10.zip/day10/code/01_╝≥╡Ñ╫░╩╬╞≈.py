

# 装饰器: 用来装饰函数的.


# 原始函数: 毛坯房
def fn():
    print("我是毛坯房")

# 原始函数: 毛坯房2
def fn2():
    print("我也是毛坯房")


# 装饰函数
def fn3(f):
    f()
    print("增加了天花板")


fn3( fn )
fn3( fn2 )

print()


# Python装饰器语法
def out(f):

    def inner():

        f()
        print("这里写增加的装饰功能")

    return inner


# 原始函数
def house():
    print("我是毛坯房")


# 调用
# res = out( house )  # res=inner
# res()  # 相当于:inner()

# 把原始的函数名覆盖: 可以不影响函数调用
#   作用: 1.如果不加装饰器,则会使用原始函数
#        2.如果加装饰器,会自动使用装饰器
house = out( house )  # house=inner, 装饰器原理

# print(house.__name__)  # inner, house指向inner函数

# 调用函数
house()


# 5,写一个装饰器来统计函数运行的时间
import time

# 装饰器函数
def outer(f):  # f=m
    def inner():
        print('before')
        start = time.time()

        f()

        end = time.time()
        print(end - start)
        print('after')
    return inner


# 原始函数
@outer
def m():
    print("m")
    for i in range(10000000):
        pass


# 使用装饰器
# m = outer(m)  # 这句话可以使用@语法糖

# 调用函数
m()








