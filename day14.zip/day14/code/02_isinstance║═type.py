
# isinstance() : 判断某对象是否属于指定的类的对象
# type() : 判断数据类型

print(type(1))  # <class 'int'>
print(isinstance(1, int))  # True
print(isinstance(1, str))  # False
print(isinstance(1, (int, str, bool)))  # True, 1属于其中的一种类型则为True


#
class Person:
    pass

class Man(Person):
    pass

# 对象
p = Person()
m = Man()

print(isinstance(m, Man))  # True
print(isinstance(m, Person))  # True
print(isinstance(m, object))  # True

print(isinstance(p, Man))  # False
print(isinstance(p, Person))  # True
print(isinstance(p, object))  # True



