

# 了解即可
# 运算符重载: 让类可以使用运算符

class Girl:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    # + 加法
    def __add__(self, other):
        return self.age + other.age


# 对象
p1 = Girl('杨超越', 22)
p2 = Girl('关晓彤', 20)

print(p1.age + p2.age)
print(p1 + p2)


