#
# 1. 利用封装和继承的特性完成如下操作：
# 	小学生：
# 		属性：
# 			姓名, 学号, 年龄, 性别
# 		行为：
# 			学习, 打架
# 	中学生：
# 		属性：
# 			姓名, 学号, 年龄, 性别
# 		行为：
# 			学习, 谈恋爱
# 	大学生：
# 		属性：
# 			姓名, 学号, 年龄, 性别
# 		行为：
# 			学习, 打游戏
# 	测试类中：
# 		创建小学生对象
# 			调用学习的方法
# 				打印内容为： xx 学习的内容为：语文 数学 英语
# 		创建中学生对象
# 			调用学习的方法
# 				打印内容为：xx 学习的内容为：语数外 生物化 史地政
# 		创建大学生对象
# 			调用学习的方法：
# 				打印内容为： 逃课中。。。。。。

# 父类
class Student:
    def __init__(self, name, sno, age, sex):
        self.name = name
        self.sno = sno
        self.age = age
        self.sex = sex

    def study(self):
        print("学习中")

# 子类
# 小学生
class Pupil(Student):
    def __init__(self, name, sno, age, sex):
        super().__init__(name, sno, age, sex)

    def study(self):
        print(f'{self.name} 学习的内容为：语文 数学 英语')

    def fight(self):
        print("打架")


# 中学生
class MiddleStudent(Student):
    def __init__(self, name, sno, age, sex):
        super().__init__(name, sno, age, sex)

    def study(self):
        print(f'{self.name} 学习的内容为：语数外 生物化 史地政')

    def love(self):
        print("谈恋爱")


# 大学生
class UniversityStu(Student):
    def __init__(self, name, sno, age, sex):
        super().__init__(name, sno, age, sex)

    def study(self):
        print('逃课中。。。。。')

    def play_game(self):
        print("打游戏")


# 对象
p = Pupil("晓明", '001', 10, "男")
p.study()
p2 = MiddleStudent("晓明", '002', 16, "男")
p2.study()
p3 = UniversityStu("晓明", '003', 20, "男")
p3.study()


# 2.主人杨夫人 向客人 李小姐介绍自己家的宠物狗和宠物猫
# 		宠物狗：
# 			昵称是：贝贝
# 			年龄是：2
# 			性别：雌
# 			会两条腿行走的才艺
# 		宠物猫
# 			昵称是：花花
# 			年龄是 1
# 			性别是：雄
# 			会装死的才艺

# 父类
class Pet:
    def __init__(self, name, age, sex):
        self.name = name
        self.age = age
        self.sex = sex

    def skill(self):
        print("才艺")


# 子类
class Dog(Pet):
    def __init__(self, name, age, sex):
        super().__init__(name, age, sex)
    def skill(self):
        print("会两条腿行走")

class Cat(Pet):
    def __init__(self, name, age, sex):
        super().__init__(name, age, sex)
    def skill(self):
        print("会装死")

# 杨夫人
class Person:
    def __init__(self, name, dog, cat):
        self.name = name
        self.dog = dog
        self.cat = cat

    def introduce(self, custom):
        print(f'主人{self.name} 向客人{custom}介绍自己家的宠物狗{self.dog.name}和宠物猫{self.cat.name}')


# 3.
# 	学生类：姓名、年龄、学号、成绩
# 	班级类：班级名称、学生列表
# 		显示所有学生
# 		根据学号查找学生
# 		添加一个学生
# 		删除一个学生（学生对象、学号）
# 		根据学号升序排序
# 		根据成绩降序排序

# 学生
class Student:
    def __init__(self, name, age, sno, score):
        self.name = name
        self.age = age
        self.sno = sno
        self.score = score

    def __str__(self):
        return f"姓名: {self.name}, 年龄: {self.age}, 学号:{self.sno}, 成绩:{self.score}"

# 班级
class Class:
    def __init__(self, name, stu_list):
        self.name = name
        self.stu_list = stu_list

    # 显示所有学生
    def show_stu(self):
        for stu in self.stu_list:
            print(stu)

    # 根据学号查找学生
    def find_by_sno(self, sno):
        for stu in self.stu_list:
            if stu.sno == sno:
                print(stu)
                break

    # 添加一个学生
    def add_stu(self, name, age, sno, score):
        stu = Student(name, age, sno, score)
        self.stu_list.append(stu)
        print(self.stu_list)

    # 删除一个学生（学生对象、学号）
    def del_stu(self, sno):
        for i in range(len(self.stu_list)):
            if self.stu_list[i].sno == sno:
                self.stu_list.pop(i)
                break
        print(self.stu_list)

    # 根据学号升序排序
    def sort_stu_asc(self):
        return sorted(self.stu_list, key=lambda x:x.sno)


    # 根据成绩降序排序
    def sort_stu_desc(self):
        return sorted(self.stu_list, key=lambda x:x.score, reverse=True)


# 创建学生
stu_list = []
for i in range(1, 6):
    name = "鹿晗" + str(i)
    age = 20 + i
    sno = 100 + i
    score = 90 + i

    stu = Student(name, age, sno, score)
    stu_list.append(stu)

# 创建班级
c = Class("Python2003", stu_list)
c.show_stu()
c.find_by_sno(103)

stu_list2 = c.sort_stu_desc()
for stu in stu_list2:
    print(stu)
