

# 面向对象的特征:
#   封装: 用类将属性和方法封装在一起,配合私有属性和私有方法使用
#   继承: 子类可以继承父类的属性和方法, 子类可以扩展自己的属性和方法
#       使用场景:
#           1. 子类完全继承父类的所有属性和方法的情况,
#               如:动物类和狗类, 动物类作为父类,狗类作为子类, 一般有从属关系
#           2. 如果父类中有部分属性或方法不继承,则需要将他们的公共的属性和方法抽取出来作为父类
#               如:狗类和猫类, 将狗和猫的共同属性和方法提取出来作为父类
#   多态[了解]: 在继承的基础上,而且需要用重写. 要在父类中定义一个方法,让所有子类重写该方法,那么我们可以使用父类对象去指向不同的子类来调用同一个方法名,则有不同的状态或结果
#

# 父类
class Animal:
    def bark(self):
        pass

# 子类
class Dog(Animal):
    def bark(self):
        print("汪汪的叫")

class Cat(Animal):
    def bark(self):
        print("喵喵的叫")

class Wolf(Animal):
    def bark(self):
        print("嗷嗷的叫")


#
class Person:
    def __init__(self, name):
        self.name = name

    def beat_animal(self, animal):
        print(f'{self.name}正在殴打小动物')
        animal.bark()

# 对象
dog = Dog()
cat = Cat()
wolf = Wolf()

xiaoming = Person("黄晓明")
xiaoming.beat_animal(wolf)


