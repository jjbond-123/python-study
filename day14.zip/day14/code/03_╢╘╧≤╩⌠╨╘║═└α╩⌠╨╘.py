
#
class Person:
    # 类属性(类变量)
    name = "鹿晗"
    # age = 10

    # 如果类属性的值是引用类型,则该类属性会被当前类创建的所有对象共享
    likes = ['关晓彤', '舒淇']

    def __init__(self, age):
        # 对象属性(成员变量)
        self.age = age

        # 这里不会共享
        self.likes2 = ['关晓彤', '舒淇']


# 对象
p = Person(18)
# print(p.name)  # 对象.类属性
# print(Person.name)  # 类.类属性
# print(p.age)  # 对象.对象属性
# print(Person.age)  # 类.对象属性,报错Error

# 针对相同名称的类属性和对象属性
# # 获取
# print(p.age, Person.age)  # 18 10
# # 修改
# # p.age = 20  # 会修改对象属性的值
# Person.age = 12  # 会修改类属性的值
# print(p.age, Person.age)  # 18 12


# 扩展: 类属性如果是引用类型,则会共享
# p2 = Person(30)
# p3 = Person(30)
# print(p2.likes)  # ['关晓彤', '舒淇']
# print(p3.likes)  # ['关晓彤', '舒淇']
# p3.likes.append('吴亦凡')
# print(p2.likes)  # ['关晓彤', '舒淇', '吴亦凡']
# print(p3.likes)  # ['关晓彤', '舒淇', '吴亦凡']


p2 = Person(30)
p3 = Person(30)
print(p2.likes2)  # ['关晓彤', '舒淇']
print(p3.likes2)  # ['关晓彤', '舒淇']
p3.likes2.append('吴亦凡')
print(p2.likes2)  # ['关晓彤', '舒淇']
print(p3.likes2)  # ['关晓彤', '舒淇', '吴亦凡']



