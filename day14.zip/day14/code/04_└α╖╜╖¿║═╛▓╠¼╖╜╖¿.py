
# 类方法: @classmethod
# 静态方法: @staticmethod

class Person:
    age = 10

    # 构造方法/构造函数
    def __init__(self, name):
        self.name = name

    # 成员方法(常用)
    def sleep(self):
        print("睡觉:", self)

    # 私有方法
    def __run(self):
        print("跑步")

    # 类方法:
    #   1. 可以使用类和对象调用,但是建议使用类来调用,可以节省内存
    #   2. 可以使用类属性和其他类方法, 但是不能使用对象属性和成员方法和私有方法
    #   3. 一般用在功能比较单独,和类中其他属性和方法无关的情况下
    # cls: class
    @classmethod
    def eat(cls):
        # print(cls.name)  # 在类方法中不能使用对象属性和成员方法,因为没有self
        print("吃饭:", cls==Person)  # True

    # 静态方法:
    #   1. 可以使用类和对象调用,但是建议使用类来调用,可以节省内存
    #   2. 不可以使用对象属性,成员方法和私有方法,一般也不用类属性和类方法
    #   3. 就是一个非常普通的函数,只是写类里面
    @staticmethod
    def sing():
        print("唱歌")


# 对象
p = Person("蔡徐坤")
Person.eat()  # 类.类方法, 推荐
# p.eat()  # 对象.类方法

# Person.sleep(p)  # 类.成员方法 , 不推荐,尽量不这么用
p.sleep()  # 对象.成员方法, 推荐

#
Person.sing()  # 类.静态方法, 推荐
# p.sing()  # 对象.静态方法

