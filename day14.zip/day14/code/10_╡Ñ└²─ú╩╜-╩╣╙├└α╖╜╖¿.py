

# 使用类方法

class Singleton:
    instance = None

    @classmethod
    def get_instance(cls):
        if not cls.instance:
            cls.instance = cls()
        return cls.instance


s1 = Singleton.get_instance()
s2 = Singleton.get_instance()
print(s1 is s2)  # True


