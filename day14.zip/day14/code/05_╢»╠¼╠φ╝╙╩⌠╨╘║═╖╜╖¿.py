
class Person:
    age = 20

    def __init__(self, name):
        self.name = name


# 对象
p = Person("成龙")
print(p.name)  # "成龙"

# 动态添加属性: 只存在于当前对象中
p.age = 10
print(p.name, p.age, Person.age)  # 成龙 10 20
# print(Person("李小龙").age)  # 报错


# 动态添加方法: 了解
# def sleep(self):
#     print(self.name, "在睡觉")
# p.sleep2 = sleep
#
# p.sleep2(p)  # 调用

from types import MethodType
def sleep(self):
    print(self.name, "在睡觉")

p.sleep3 = MethodType(sleep, p)

p.sleep3()  # 调用








