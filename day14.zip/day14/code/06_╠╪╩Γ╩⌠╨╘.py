
# __name__
# __mro__

class Boy:
    pass

class Renyao(Boy):
    def __init__(self, name, age):
        self.name = name
        self.age = age


# 对象
p = Renyao("泰国人妖皇后", 20)
# print(Renyao.__name__)  # 'Renyao'
# print(p.__class__)  # <class '__main__.Renyao'>
print(p.__dict__)  # {'name': '泰国人妖皇后', 'age': 20}

# print(Renyao.__dict__)  # {'__module__': '__main__', '__init__': <function Renyao.__init__ at 0x0000023A8F81C9D8>, '__doc__': None}
# print(p.__module__)  # __main__ 模块
# print(Renyao.__module__)  # __main__ 模块
# print(Renyao.__bases__)  # 父类 (<class '__main__.Boy'>,)
print(Renyao.__mro__)  # 继承链 (<class '__main__.Renyao'>, <class '__main__.Boy'>, <class 'object'>)

print(__name__)  # __main__
