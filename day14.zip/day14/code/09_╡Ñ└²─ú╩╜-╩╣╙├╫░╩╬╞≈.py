
# 装饰器
def outer(cls):
    instance = None
    print("instace初始化为None")

    def inner(*args, **kwargs):
        nonlocal instance

        if not instance:
            print("---创建了新对象---")
            instance = cls(*args, **kwargs)

        print('--返回对象--')
        return instance

    return inner


@outer
class Person:
    pass


p1 = Person()
p2 = Person()
p3 = Person()
print(p1 is p2)  # True


