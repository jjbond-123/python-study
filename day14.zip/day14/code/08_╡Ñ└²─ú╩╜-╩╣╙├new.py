
# 单例模式: 是一种设计模式
#
# 设计模式: 23种设计模式, 比如: 单例模式,工厂模式,代理模式,装饰器模式,适配器模式....
#   是一种解决问题的方式

# 单例模式:
#   让类只能创建出一个对象.

# 方法一: 使用new

class Person(object):

    # 构造函数: 用来对属性初始化
    def __init__(self, name):
        print("__init__")
        self.name = name

    # 类属性
    instance = None

    # new方法:用来创建对象
    @classmethod
    def __new__(cls, *args, **kwargs):
        print("__new__")

        if not cls.instance:
            print("---创建新对象---")

            cls.instance = super().__new__(cls)  # 新建对象

        return cls.instance

# 对象
p = Person("1")
p2 = Person("2")
p3 = Person("3")

print(p.name)
print(p == p2)  # True
print(p == p3)  # True






