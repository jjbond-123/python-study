''''''

#
# 统计文件夹大小 (os.path.getSize()：获取文件大小)
#




