
import os


# 遍历目录
def search_dir(path):

    filename_list = os.listdir(path)

    for filename in filename_list:
        # file_path: 每个子文件或子文件夹的绝对路径
        file_path = os.path.join(path, filename)

        # 如果是文件
        if os.path.isfile(file_path):
            print("文件名:", filename)
        # 如果是目录
        elif os.path.isdir(file_path):
            print("目录名:", filename)

            # 递归遍历当前目录的子目录
            search_dir(file_path)


search_dir(r'C:\Users\ijeff\Desktop\Python2003\day11\code\newdir')
