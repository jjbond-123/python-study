
# hello.py是一个自定义模块

age = 18


def login():
    print("login")


