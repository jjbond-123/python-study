
# os: operation system 操作系统
#   主要提供根操作系统相关的函数

import os

# 了解
# print(os.name)  # nt (windows)
# print(os.environ)  # 环境变量
# print(os.environ.get('PATH'))

# curdir: current directory 当前目录(当前文件夹)
# . 表示当前目录
# .. 表示上一级目录
# print(os.curdir)  # .


# 获取当前目录(路径)
# 绝对路径: 从磁盘开始的完整路径, 比如: C:/Users/ijeff/Desktop/Python2003/day11/code
# 相对路径: 从当前目录开始的路径, 比如: /day11/code
print(os.getcwd())  # C:\Users\ijeff\Desktop\Python2003\day11\code


# listdir(): 重点掌握
#   获取指定目录下的所有文件夹和文件的名称,会得到一个列表
# r'' : 可以让字符串里面的字符没有语义
print(os.listdir(r'C:\Users\ijeff\Desktop\Python2003'))

# mkdir() : make dir 创建目录
# 注意: 如果文件已存在, 则会报错
# os.mkdir("罗志祥")
# os.mkdir("薛之谦/演员/丑八怪")  # 报错

# os.makedirs("薛之谦/演员/丑八怪")  # 可以创建多层目录

# 删除目录
# os.rmdir("罗志祥")
# os.rmdir("薛之谦")  # 报错, 目录不是空的。: '薛之谦'

# 重命名
# os.rename("薛之谦", "李荣浩")  # 文件夹
# os.rename('a.py', 'abc.py')  # 文件

# 删除文件
# os.remove('abc.py')

# 文件属性
# print(os.stat(r'01_os模块_上.py'))


# 重点掌握:
#   getcwd(), listdir(), mkdir()/makedirs(), rmdir()


