
import os


# 查找某个目录下的py文件和txt文件
def get_file(path):

    # 判断path是否存在
    if not os.path.exists(path):
        print("路径不存在")
        return

    # 1.获取当前path下的所有子文件和子文件夹名称
    file_list = os.listdir(path)
    # print(file_list)

    # 2.获取子文件的路径
    for file in file_list:
        file_path = os.path.join(path, file)
        # print(file_path)

        # 3.判断是否为文件,且是否为.py或.txt文件
        if os.path.isfile(file_path):
            if file_path.endswith(".py") or file_path.endswith('.txt'):
                # 打印文件名
                print(file)


get_file(r'C:\Users\ijeff\Desktop\Python2003\day11\code2')

