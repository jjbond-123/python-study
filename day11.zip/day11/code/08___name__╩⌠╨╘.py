
import demo

# demo: 小例,示例
# print(demo.a)  # 报错






