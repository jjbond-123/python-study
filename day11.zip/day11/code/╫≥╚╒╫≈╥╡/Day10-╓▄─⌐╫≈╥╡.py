''''''

# 简答题
# 1， Python中的循环有几种:
#  while, for

# 2， Python的数据类型有哪些:
#  int, float, bool, str, list, tuple, dict, set, None, bytes

# 3， Python中空类型特殊值是:
#   None

# 4， 判断下列赋值方式正确与否（True or False）
'''
    x = y = z = 1           =>  True
    x=1, y=2                =>  False
    x, *y, z = 1,2,3,4      =>  True
    x, y, z = (1,2,3)       =>  True
'''
x, *y, z = 1,2,3,4
print(x, y, z)  # 1 [2, 3] 4
x, y, z = [1,2,3]

# 5, 列举5种常用的内置函数：
# sum, min, max, round, pow, range, int, str, float, len, print ...

# 6，判断下面变量名不正确的有哪些：
# ABC, aBC, a-bc, a_bc， _num123, 123num, NUM123, num_123，
# True, false, true1, false0， print, id, __id__, python
#
# a-bc, 123num, True

# 7，列举列表list中的至少6个函数，且说明每个函数对应的作用
'''
append(), extend([]), insert(i, n), pop(i), remove(n), clear(), sort(key, reverse), reverse()
copy()
'''

# 8，列举字典dict中的至少3个函数，且说明每个函数对应的作用
'''
update(dict2), get(key), pop(key), popitem(), keys(), values(), items()
'''



# 编程题
# 1，将列表中元素去重， 使用至少3种方式
# 方式一:
l = [1,2,2,2,3,3,3,3,4,4,4,1,1,2,2]
r = list(set(l))
print(r)

# 方式二
l = [1,2,2,2,3,3,3,3,4,4,4,1,1,2,2]
l2 = []
for i in l:
    if i not in l2:
        l2.append(i)
print(l2)

# 方式三
l = [1,2,2,2,3,3,3,3,4,4,4,1,1,2,2]
for n in l:
    for j in range(l.count(n)-1):
        l.remove(n)
print(l)

# 方式四
l = [1,2,2,2,3,3,3,3,4,4,4,1,1,2,2]
i = 0
while i < len(l):

    j = i+1
    while j < len(l):

        if l[i] == l[j]:
            l.pop(j)
            j -= 1

        j += 1

    i += 1

print(l)



# 2、编写一个函数gcd(x,y) 求最大公约数，编写一个函数lcm(x,y)求最小公倍数。
# 最大公约数
def gcd(x, y):
    min1 = min(x, y)
    for i in range(min1, 0, -1):
        if x%i==0 and y%i==0:
            return i

print( gcd(18, 12) )

# 最小公倍数
def lcm(x, y):
    return x*y // gcd(x, y)

print( lcm(18, 12) )


# 3、使用Python编程实现下面图形打印：
'''
     *  i=1  4
    **  i=2  3
   ***  i=3  2
  ****  i=4  1
 *****  i=5  0
'''
for i in range(1, 6):
    # 空格
    for j in range(5-i):
        print(" ", end='')
    # *
    for k in range(i):
        print("*", end='')
    print()


# 4、使用Python编程实现下面图形打印：
'''
     *       i=1  1
    ***      i=2  3
   *****     i=3  5
  *******    i=4  7
 *********   i=5  9
'''
for i in range(1, 6):
    # 空格
    for j in range(5-i):
        print(" ", end='')
    # *
    for k in range(2*i-1):
        print("*", end='')
    print()



# 5，将字典的key和value置换，
# 如使用字典 d1 = {'a':1,'b':2,'c':3}，
#   生成字典 d2 = {1:'a', 2:'b', 3:'c'}
d1 = {'a':1,'b':2,'c':3}
d2 = {}
for k, v in d1.items():
    d2[v] = k

d1 = {'a':1,'b':2,'c':3}
d2 = {v:k for k,v in d1.items()}
print(d2)


# 6、使用Python写一个按照下面方式调用都能正常工作的 my_sum() 方法
'''
    print(my_sum(2,3))     输出 5
    print(my_sum(2)(3))    输出 5
'''
# 提示:
#   1. 函数嵌套
#   2. 通过参数数量判断不同的情况
def my_sum(*args):

    if len(args) == 2:
        return sum(args)

    elif len(args) == 1:
        x = args[0]
        def f(y):
            return x + y
        return f

print(my_sum(2, 3))
print(my_sum(2)(3))


# 7， 封装函数，传入不定数量的数值型参数，返回所有数字的乘积,
# 提示: *args
def f7(*args):
    s = 1
    for i in args:
        s *= i
    return s


# 8， 封装一个函数random_color，该函数的返回值为随机十六进制颜色。
# 说明： 十六进制颜色#开头后面接6个十六进制数， 例: #FFFFFF， #000000， #0033CC
# 提示: colors = '0123456789ABCDEF'
#      random模块
import random
colors = '0123456789ABCDEF'
s = "#"
for i in range(6):
    s += random.choice(colors)
print(s)


# 9， 封装函数，
# 第一个函数create_persons(), 创建并返回包含5个字典(例如:{"name":"xx","age":xx, "faceValue":100})的列表
#                           其中name的值：从["张三","李四","王五","赵六","钱七"]依次取
#                           其中age的值：10-100之间的随机整数
#                           其中faceValue的值：0-100之间的随机整数
# 第二个函数get_old(), 传入第一个函数创建的列表, 找出列表中年龄最大的人，并将其所有信息打印
# 第三个函数sort_facevalue(), 传入第一个函数创建的列表, 根据颜值升序排列，并打印排序后的信息

def create_persons():
    name_list = ["张三","李四","王五","赵六","钱七"]
    person_list = []

    for i in range(5):
        name = name_list[i]
        age = random.randint(10, 100)
        faceValue = random.randint(0, 100)

        person_list.append({"name": name,"age": age, "faceValue": faceValue})
    print(person_list)
    return person_list

'''
[
    {'name': '张三', 'age': 38, 'faceValue': 87}, 
    {'name': '李四', 'age': 54, 'faceValue': 36},
    {'name': '王五', 'age': 15, 'faceValue': 25}, 
    {'name': '赵六', 'age': 52, 'faceValue': 86},
    {'name': '钱七', 'age': 62, 'faceValue': 99}
]

'''
def get_old(persons):
    max_age = 0
    for p in persons:
        if p['age'] > max_age:
            max_age = p['age']
    print(max_age)

    for p in persons:
        if p['age'] == max_age:
            print(p)


def sort_facevalue(persons):
    persons.sort(key=lambda x:x['faceValue'])
    print(persons)


# 调用
persons = create_persons()

get_old(persons)
sort_facevalue(persons)



from collections import deque


