''''''

# 1,使用递归实现：计算某个数的阶乘

# 2,兔子繁殖问题。
#     设有一对新生的兔子，从第4个月开始他们每个月月初都生一对新兔子，
#     新生的兔子从第4个月开始又每个月月初生一对兔子。
#     按此规律，并假定兔子没有死亡，20个月末共有多少对兔子？


# 3,封装函数，传入n，得到 第n个 斐波那契数
#  	    1 1 2 3 5 8 13 21
# 公式: f(n) = f(n-1) + f(n-2)
# 临界值: f(1)=f(2) = 1
def f(n):
    if n == 1 or n == 2:
        return 1
    return f(n-1) + f(n-2)


# 4,封装函数，传入n，得到 前n个 斐波那契数
#  	    1 1 2 3 5 8 13 21
def f2(n):
    for i in range(1, n+1):
        r = f(i)
        print(r, end=' ')

f2(8)


# 5,写一个装饰器来统计函数运行的时间
import time
def outer(f):
    def inner():
        start = time.time()
        f()
        end = time.time()
        print(end - start)
    return inner


@outer
def f5():
    for i in range(1000000):
        # print("f5")
        pass


f5()


