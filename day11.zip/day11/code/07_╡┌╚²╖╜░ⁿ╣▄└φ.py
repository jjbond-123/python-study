
# 第三方包
# requests
# import requests

# 安装第三方包
#   方式一: 在pycharm中安装
#       a. 在需要安装的包名上按alt+enter选择'install package requests'
#       b. 在file=>settings=>Project=>点击右上角的+进行安装.
#
#   方式二: 使用命令安装pip
#       pip -V  查看pip的版本
#       pip install package 安装包 (默认会从国外的网站下载安装)
#          pip install package -i 国内源 (不会被墙)
#           豆瓣源: https://pypi.douban.com/simple/
#           清华源: https://pypi.tuna.tsinghua.edu.cn/simple
#       pip uninstall package 卸载包
#       pip list 列出(查看)所有的包
#       pip freeze  列出(查看)你安装的包(除了自带的pip,setuptools等)
#       pip show package 显示包详情


