
# 包: package
#   就是一个包含__init__.py的文件夹


# import
# 格式: import 包.模块
import aaa.bbb  # 这句话执行会打印出'bbb'
print(aaa.bbb.sex)  # '人妖'
# print(bbb.sex)  # 报错
# print(sex)  # 报错

# 推荐使用下面的方式导入包中的模块
# from..import..
from aaa import bbb
print(bbb.sex)

from aaa.bbb import sex
print(sex)












