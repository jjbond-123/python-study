
print("bbb")


sex = "人妖"


