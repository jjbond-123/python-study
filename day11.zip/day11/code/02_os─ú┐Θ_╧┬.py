import os

# abspath(): 获取指定文件的绝对路径
print(os.path.abspath(r'01_os模块_上.py'))


# join(): 拼接路径
print(os.path.join(r'C:\Users\ijeff\Desktop\Python2003\day11', "hello.py"))
# 'C:\Users\ijeff\Desktop\Python2003\day11\hello.py'

# split(): 分割
print(os.path.split(r'C:\Users\ijeff\Desktop\Python2003\day11\hello.py'))
# ('C:\\Users\\ijeff\\Desktop\\Python2003\\day11', 'hello.py')

# splittext() : 把文件的名称和扩展名分割
print(os.path.splitext('hello.py'))
#  ('hello', '.py')

#
my_dir = r'C:\Users\ijeff\Desktop\Python2003\day11'
my_file = r'C:\Users\ijeff\Desktop\Python2003\day11\code\01_os模块_上.py'

# isdir() : 判断是否为文件夹(目录)
print(os.path.isdir(my_dir))  # True
print(os.path.isdir(my_file))  # False

# isfile() : 判断是否为文件
print(os.path.isfile(my_dir))  # False
print(os.path.isfile(my_file))  # True

# exists() : 判断是否存在
print(os.path.exists(my_dir))  # True
print(os.path.exists(my_file))  # True


# getsize() : 获取文件大小
print(os.path.getsize(my_file))  # 1492

# dirname(): 父目录
print(os.path.dirname(my_file))

# basename() : 文件名
print(os.path.basename(my_file))

# 当前文件路径
print(__file__)
print(os.path.abspath(__file__))


# 了解
# dir(): 获取某个模块(python文件)中的所有属性和函数名
import math
print(dir(math))







