

def f(x, y):
    return x+y


print("模块名称(demo.py): ", __name__)  # '__main__', 'demo'


# 用来对本文件做测试.
if __name__ == '__main__':
    print("我只会在运行当前文件时才会打印")

    a = 10
    b = 20
    print(f(a, b))



