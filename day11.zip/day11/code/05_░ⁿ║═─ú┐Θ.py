
# 导入包和模块
# 模块的种类:
#   1.内置模块,标准模块
#   2.自定义模块
#   3.第三方模块

# 1. import
import os
import os, math

# math: 模块
# 用法: 模块名.函数名()
math.pow(2,3)


# import hello
# print(hello.age)
# hello.login()


# 2.from..import..
# 精确导入
# from collections.abc import Iterator

# 模糊导入
# * 表示通配符
# from hello import *

# 精确导入: 只导入需要的变量或函数或类
from hello import age, login
print(age)
# print(hello.age)  # 报错
login()


# 别名
import random as rd
print(rd.random())
# print(random.random())  # 报错

from random import randint as ri
print(ri(1,3))



