''''''

# 利用面向对象的思想写下面的程序：直接赋值
# 1.小美在朝阳公园溜旺财【注：旺财是狗】
import math


class Person:
    def __init__(self, name):
        self.name = name

    def play_dog(self, place):
        print(self.name, "在", place, "溜旺财")


xiaomei = Person("小美")
xiaomei.play_dog("朝阳公园")


# 2.小明穿着白色的特步运动鞋在奥林匹克公园跑步


# 3.赵老师在讲台上讲课，小刚认真的听课做笔记
class Teacher:
    pass

class Student:
    pass

# 4.张阿姨和李阿姨在物美超市买红富士
# 提示: 写一个阿姨类,创建2个阿姨对象


# 使用构造函数的方式写下面的程序
# 1.定义一“圆”（Circle）类，圆心为“点”Point类，构造一圆，求圆的周长和面积，并判断某点与圆的关系
# 圆:
#   属性: 半径,圆心
#   方法: 周长,面积
# 点:
#   属性: x,y

# 圆
class Circle:
    def __init__(self, r, p):
        self.r = r
        self.p = p

    def zhouchang(self):
        return 2 * self.r * 3.14

    def area(self):
        return self.r**2 * 3.14


# 点
class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def relation_circle(self, circle):
        a = self.x - circle.p.x
        b = self.y - circle.p.y
        c = math.sqrt(a*a + b*b)

        if c > circle.r:
            print("在圆外")
        elif c < circle.r:
            print("在圆内")
        else:
            print("在圆上")


# 对象
c = Circle(5, Point(3, 4))
p = Point(6, 8)

p.relation_circle(c)


# 2.李晓在家里开party，向朋友介绍家中的黄色的宠物狗【彩彩】具有两条腿走路的特异功能。
class Person2:
    pass

class Dog:
    pass


# 3.王梅家的荷兰宠物猪【笨笨】跑丢了，她哭着贴寻猪启示。
class Person3:
    pass

class Pig:
    pass


# 4.富二代张三向女朋友李四介绍自己的新跑车：白色的宾利
class Rich2:
    pass





