

# 1. 使用冒泡排序对列表进行降序排序
def sort1(l):
    for i in range(len(l)-1):
        for j in range(len(l)-1-i):
            if l[j] < l[j+1]:
                l[j], l[j+1] = l[j+1], l[j]
    print(l)


# 2.使用选择排序对列表进行升序排序
def sort2(l):
    for i in range(len(l)-1):

        min_index = i
        for j in range(i+1, len(l)):
            if l[j] < l[min_index]:
                min_index = j

        l[i], l[min_index] = l[min_index], l[i]

    print(l)


# 3.查找列表的元素找到返回下标, 找不到返回 -1
def find(l, n):
    for i in range(len(l)):
        if l[i] == n:
            return i
    return -1


# 4.使用顺序查询，获取列表中所有与指定元素重复的元素下标
def search(l, n):
    l2 = []
    for i in range(len(l)):
        if l[i] == n:
            l2.append(i)
    return l2




