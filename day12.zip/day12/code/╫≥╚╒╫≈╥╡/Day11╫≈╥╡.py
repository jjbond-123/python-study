import os

# 1.显示指定路径下所有视频格式文件, 提示: 视频格式mp4，avi，rmvb
# # filename.endswith('mp4')
def fn1(path):
    if not os.path.exists(path):
        print("路径不存在")
        return

    filename_list = os.listdir(path)
    for filename in filename_list:

        file_path = os.path.join(path, filename)
        # 文件
        if os.path.isfile(file_path):
            if file_path.endswith('.mp4') or file_path.endswith('.avi') or file_path.endswith('.rmvb'):
                print(filename)


fn1(r'C:\Users\ijeff\Desktop\Python2003\day12\code\昨日作业\dir\dir1')


# 2.自定义模块,
# 建立一个包
# 在包的下创建一个排序的模块
# 模块下的功能
# 1. 使用冒泡排序对列表进行降序排序
# def fn(l):

# 2.使用选择排序对列表进行升序排序
#
# 3.查找列表的元素找到返回下标, 找不到返回 - 1def fn(l, n):
#
# 4.使用顺序查询，获取列表中所有与指定元素重复的元素下标def fn(l, n):
#
# 在另外一个文件中导入上述包中的模块，完成模块中功能的调用
from my_package.my_sort import *

sort1([3,2,1,4,5,7,6])
sort2([3,2,1,4,5,7,6])
print( find([3,2,1,1,1,5,7,6], 10) )
print( search([3,2,1,1,1,5,7,6], 1) )





