''''''
import os
#
# 统计文件夹大小 (os.path.getSize()：获取文件大小)

# s = 0

def dir_size(path):
    s2 = 0

    if not os.path.exists(path):
        return

    filename_list = os.listdir(path)
    for filename in filename_list:

        file_path = os.path.join(path, filename)
        # 文件
        if os.path.isfile(file_path):
            size = os.path.getsize(file_path)
            # print("文件大小:", size)
            # global s
            # s += size
            s2 += size
        # 目录
        else:
            # 递归
            s2 += dir_size(file_path)

    return s2


print( dir_size(r'C:\Users\ijeff\Desktop\Python2003\day11') )
# print("s :", s)
