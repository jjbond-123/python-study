
# 类和对象

# 理解
#   类(泛指)  对象(特指,存在的某一个)
#    人        我
#    电脑      我的这台电脑
#  联想电脑     我的这台联想电脑
#   水杯       我桌上的这个水杯


# 类: 作用是用来创建对象, 是一系列事物的统称
# 对象: 通过类来创建, 是某一个具体存在的事物


# 类: 可以封装属性和方法
class HuaweiPhone:
    # 属性: 变量
    color = '绿色'
    size = '6.2'
    price = 7000

    # 方法: 函数
    # self: 不是关键字, 是存在于类中的函数里面的特殊形参
    # self: 翻译=> 自己
    # self: 是指向当前类的一个对象, 哪个对象调用了方法,则该self就是这个对象
    def call(self, name):
        print("打电话给", name, self.color)
        print("self:", id(self))

    def game(self):
        print("玩吃鸡")


# 对象: 通过类来创建对象(实例)
#    一个类可以创建出任意多个不同的对象
p40 = HuaweiPhone()
# print(p40)  # <__main__.HuaweiPhone object at 0x000002233463A198>
# print(p40.color, p40.size, p40.price)
# p40.call("小丽")
# p40.game()

print('p40:', id(p40))
p40.call("小美")


# p50对象
p50 = HuaweiPhone()
print('p50:', id(p50))
p50.call("小美")
