''''''

'''
dt_now = datetime.datetime.now()
        获取当前的日期对象，包含时间的
dt_ziding = datetime.datetime()
        根据指定的日期、时间生成一个日期对象
        
dt.strftime()  将日期对象转化为指定的格式
dt.date()   获取日期对象中的日期
dt.time()   获取日期对象中的时间
dt.timestamp()  获取日期对象的时间戳
dt.hour\minute\second  获取小时、分钟、秒

datetime.datetime.fromtimestamp()
        根据一个时间戳，转化为指定的日期对象
datetime.timedelta()
        生成一个差值对象，可以和日期对象直接进行相加减
        参数有，days,hours,minutes,seconds
'''

# 掌握
import datetime

# 当前时间的日期对象
d = datetime.datetime.now()
print(d, type(d))  # <class 'datetime.datetime'>

# 创建指定的日期对象
d = datetime.datetime(year=2030, month=1, day=2)
print(d)
print(d.year, d.month, d.day)  # 日期
print(d.hour, d.minute, d.second)  # 时间
print(d.date(), d.time())  # 日期 + 时间

print(d.timestamp())  # 时间戳, 1893513600
print(d.strftime("%Y-%m-%d"))  # 格式化字符串输出

# 时间戳 => 日期对象
# print(datetime.datetime.fromtimestamp(1893513600))

# 时间差
d2 = datetime.timedelta(days=7, hours=10)

print(d + d2)  # 7天之后的日期
print(d - d2)  # 7天之前的日期



