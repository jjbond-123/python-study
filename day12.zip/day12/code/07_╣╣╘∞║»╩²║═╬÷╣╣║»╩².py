

# 类
class Person:

    # 类属性
    # name = "鹿晗"

    # 方法
    # 构造方法/构造函数
    #   1. 会在创建对象时自动被调用
    #   2. 作用是用于初始化属性
    #   3. 如果不写init函数,内部自动会创建一个空init函数
    def __init__(self, name2):
        # 对象属性
        self.name = name2

    # 成员方法
    def run(self):
        print("跑步")

    # 析构函数: 在销毁对象时会被自动调用, 一般可以不写
    def __del__(self):
        print("析构函数被调用")


# 对象
p = Person("鹿晗")
print(p.name)


p2 = Person("蔡徐坤")
print(p2.name)


# del p, p2
# print("end")

