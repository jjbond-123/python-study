
import time

# 重点掌握:
#    time.time()
#    time.sleep()

# 时间戳: 距离1970年1月1日的秒数

# 获取当前时间戳
t = time.time()
print(t)  # 1594090520.6840744

# 时间戳 <==> 时间元组
print(time.gmtime())  # 当前时间的时间元组, UTC
print(time.gmtime(1694090670))  # 时间戳 => 时间元组
# time.struct_time(tm_year=2020, tm_mon=7, tm_mday=7, tm_hour=2, tm_min=55, tm_sec=20, tm_wday=1, tm_yday=189, tm_isdst=0)

t2 = time.localtime(t)
print(t2)  # 时间元组, 本地时间
print(t2[0])  # 年
print(t2[1])  # 月
print(t2[2])  # 日

# 时间元组 => 时间戳
print(time.mktime(t2))


# 时间元组 <==> 时间字符串
# 时间元组 => 字符串
t = time.localtime()
s = time.strftime("%Y-%m-%d %H:%M:%S", t)  # '2020-07-07 11:08:56'
s = time.strftime("%x %X", t)  # '07/07/20 11:10:35'
# s = time.strftime("%Y年%m月%d", t)  # 报错
s = time.strftime("%Y{}%m{}%d{}", t).format("年", "月", "日")  # '2020年07月07日'
print(s)

# 字符串 => 时间元组
s2 = '2020-07-07 11:08:56'
t2 = time.strptime(s2, '%Y-%m-%d %H:%M:%S')
print(t2)


# 输出格式化的字符串
t = time.localtime()
# print(time.asctime(t))  # Tue Jul  7 11:17:51 2020

s3 = time.ctime(time.time())
print(s3)  # Tue Jul  7 11:19:13 2020


# time.sleep(): 暂停,会阻塞程序
time.sleep(0.5)



'''
%y 两位数的年份表示（00-99）
%Y 四位数的年份表示（000-9999）
%m 月份（01-12）
%d 月内中的一天（0-31）
%H 24小时制小时数（0-23）
%I 12小时制小时数（01-12）
%M 分钟数（00-59）
%S 秒（00-59）
%a 本地简化星期名称
%A 本地完整星期名称
%b 本地简化的月份名称
%B 本地完整的月份名称
%c 本地相应的日期表示和时间表示
%j 年内的一天（001-366）
%p 本地A.M.或P.M.的等价符
%U 一年中的星期数（00-53）星期天为星期的开始
%w 星期（0-6），星期天为星期的开始
%W 一年中的星期数（00-53）星期一为星期的开始
%x 本地相应的日期表示
%X 本地相应的时间表示
%% %号本身
'''




