
import hashlib

# md5加密: 对字符串
m = hashlib.md5()
m.update("ABCabc_,..dfs234123,?".encode())
m2 = m.hexdigest()  # 获取16进制的密文
print(m2)
print(len(m2))  # 32位长度的16进制数

# 加密算法:
#   md5 : 不可逆(不能解密), 对称加密(明文和密文一一对应)
#   RSA : 非对称加密, 需要公钥和私钥.
#   AES,DES: 对称加密,可逆的,但是需要一个专门的key

# 明文
# 密文


# encode(): 编码 字符串=>二进制
# decode(): 解码 二进制=>字符串


#
# 补码
# rgb: red     green    blue
#      0~255   0~255    0~255
# 像素
#


