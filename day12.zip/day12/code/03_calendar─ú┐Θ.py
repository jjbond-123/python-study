
# 日历: 了解
import calendar

c = calendar.calendar(2020, w=2, l=1, c=6)
c = calendar.month(2020, 7)
print(c)
print(calendar.isleap(2020))  # True
print(calendar.leapdays(1900, 2020))  # 29

print(calendar.monthcalendar(2020, 7))
'''
[
    [0,  0,  1,  2,  3,  4,  5], 
    [6,  7,  8,  9,  10, 11, 12], 
    [13, 14, 15, 16, 17, 18, 19], 
    [20, 21, 22, 23, 24, 25, 26], 
    [27, 28, 29, 30, 31, 0,  0]
]

'''
print(calendar.monthrange(2020, 6))  # (2, 31)



'''
calendar(year,w=2,l=1,c=6)  
   打印某一年的日历【c月份间隔距离; w每日宽度间隔; l是每星期行数 】
       
isleap(year)   判断是否是闰年

leapdays(y1, y2)  [y1, y2) 中间闰年的个数

month(year,month,w=2,l=1)  打印指定月份的日历

monthcalendar(year,month)  
   返回一个整数的单层嵌套列表。每个子列表装载代表一个星期的整数。
   Year年month月外的日期都设为0;范围内的日子都由该月第几日表示，从1开始。

monthrange(year,month)  
   返回两个整数。第一个是该月的星期几的日期码，第二个是该月的日期码。
   日从0（星期一）到6（星期日）;月从1到12。
'''
