''''''
import random

'''

初级：
1.已知字符串：“this is a test of Python”
	a.统计该字符串中字母s出现的次数
	b.取出子字符串“test”   提示: str.find('test') 
	c.采用不同的方式将字符串倒序输出 
	d.将其中的"test"替换为"exam"  str.replace()
'''
# a.统计该字符串中字母s出现的次数
s = "this is a test of Python"
count = 0
for c in s:
    if c == 's':
        count += 1
print(count)

# b.取出子字符串“test”   提示: str.find('test')
s = "this is a test of Python"
start = s.find('test')
end = start + len('test')
print( s[start:end] )

# c.采用不同的方式将字符串倒序输出
s = "this is a test of Python"
print(s[::-1])

s2 = ""
for i in range(len(s)-1, -1, -1):
    s2 += s[i]
print(s2)

s3 = ""
for c in s:
    s3 = c + s3
print(s3)

# d.将其中的"test"替换为"exam"  str.replace()
s = "this is a test of Python"
s2 = "exam"
s3 = s.replace('test', s2)
print(s)  # 'this is a test of Python'
print(s3)  # 'this is a exam of Python'


'''
2.已知字符串 a = "aAsmr3idd4bgs7Dlsf9eAF",要求如下
	a.请将a字符串的大写改为小写，小写改为大写 ch.lower()小写， ch.upper()大写
	b.请将a字符串的数字取出，并输出成一个新的字符串 ch>='0' and ch<='9'
	c.请统计a字符串出现的每个字母的出现次数（忽略大小写，a与A是同一个字母），
	    并输出成一个字典。 例 {'a':4,'b':2}
	d.输出a字符串出现频率最高的字母
	e.请判断'boy'里出现的每一个字母，是否都出现在a字符串里。
	    如果出现，则输出True，否则，则输 出False

'''
a = "aAsmr3idd4bgs7Dlsf9eAF"

# a.请将a字符串的大写改为小写，小写改为大写  提示: ch.lower()小写， ch.upper()大写
a2 = ""
for c in a:
    # 小写字母
    if c>='a' and c<='z':
        a2 += c.upper()
    # 大写字母
    elif c>='A' and c<='Z':
        a2 += c.lower()
    else:
        a2 += c

print(a2)  # AaSMR3IDD4BGS7dLSF9Eaf

# b.请将a字符串的数字取出，并输出成一个新的字符串 ch>='0' and ch<='9'
a = "aAsmr3idd4bgs7Dlsf9eAF"
a3 = ""
for c in a:
    # 数字
    if c>='0' and c<='9':
        a3 += c

print(a3)


# c.请统计a字符串出现的每个字母的出现次数（忽略大小写，a与A是同一个字母），
# 	    并输出成一个字典。 例 {'a':4,'b':2}
a = "aAsmr3idd4bgs7Dlsf9eAF"
d = {}

for c in a:
    # 判断是否为字母
    if c>='a' and c<='z' or c>='A' and c<='Z':
        # 转换成小写
        c2 = c.lower()

        #
        if c2 not in d:
            d[c2] = 1
        else:
            d[c2] += 1

print(d)

# d.输出a字符串出现频率最高的字母
l = list(d.values())
# print(l, max(l))
max_count = max(l)  # 最大次数

for k,v in d.items():
    if v == max_count:
        print(k, end=', ')

print()
# e.请判断'boy'里出现的每一个字母，是否都出现在a字符串里。
# 	    如果出现，则输出True，否则，则输 出False
a = "aAsmr3idd4bgs7Dlsf9eAF"

for c in "boy":
    if c not in a:
        print(False)
        break
else:
    print(True)


'''
注：能不使用系统功能的尽量不要使用，自己实现
中级
1.去除字符串两端的指定字符.
s = "hello"
ch = "h"
# ello
'''
s = "hhhhhelhhlohhhhhh"
ch = 'h'

i = 0
while i < len(s):
    if s[i] == ch:
        s = s[1:]
        i -= 1
    else:
        break
    i += 1
print(s)  # elhhlohhhhhh

i = len(s) - 1
while i >= 0:
    if s[i] == ch:
        s = s[:-1]
    else:
        break
    i -= 1

print(s)  # elhhlo


'''
2.键盘输入一句英文 将每个单词的首字母大写
	例如:
		输入: hello nice to meet you
		转化之后: Hello Nice To Meet You

'''
s = "hello nice to meet you"
s2 = ""
for i in range(len(s)):
    if i==0 or s[i-1]==" ":
        s2 += s[i].upper()
    else:
        s2 += s[i]

print(s2)  # Hello Nice To Meet You

'''
3.输入一个字符串，压缩字符串如下aabbbccccd变成a2b3c4d1
'''
s = "aabbbccccd"
d = {}
for c in s:
    if c not in d:
        d[c] = 1
    else:
        d[c] += 1

print(d)  # {'a': 2, 'b': 3, 'c': 4, 'd': 1}

s2 = ""
for k, v in d.items():
    s2 = s2 + k + str(v)

print(s2)  # a2b3c4d1


'''

4.完成猜拳游戏
		-----------------------------
		请输入你的选择:
		1. 石头
		2. 剪刀
		3. 布
		-----------------------------
		你的选择是【布】, 电脑的选择是【石头】
		恭喜你获得了胜利！


'''

print('''-----------------------------
		请输入你的选择:
		1. 石头
		2. 剪刀
		3. 布
-----------------------------''')

while True:
    me = int(input("请出拳(输入编号):"))
    computer = random.randint(1,3)
    print(me, computer)

    if me-computer == -1 or me-computer == 2:
        print("恭喜你获得胜利!")
        break
    elif me == computer:
        print("平手")
    else:
        print("我输了")








