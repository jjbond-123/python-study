

# 变量: 可以改变的量
# 定义变量/声明变量
x = 10
print(x)

y = 3
print(x * y)


y = "hello"
print(y)

x = y = 1
print(x, y)

x, y = 2, 3
print(x, y)  # 2 3

# 交互2个变量的值
x, y = y, x
print(x, y)  # 3 2


# 删除变量
z = 1
print(z)  # 1

# del z
# print(z)


# 关键字
import keyword
print(keyword.kwlist)
'''
[
    'False', 'None', 'True', 'and', 'as', 'assert', 
    'break', 'class', 'continue', 'def', 'del', 'elif', 
    'else', 'except', 'finally', 'for', 'from', 'global', 
    'if', 'import', 'in', 'is', 'lambda', 'nonlocal', 'not', 
    'or', 'pass', 'raise', 'return', 'try', 'while', 'with', 'yield'
]

'''

# 13abc  不合法
# abc-12  不合法
# abc_12  可以
# and  不合法,是关键字
# _abc  合法
# my_nice_banana 合法, 下划线连接多个单词(推荐)
# myNiceBanana 合法, 驼峰




