
# 输出
x = 3
y = 4
print("x+y=", x+y)


# 输入
# input: 会等待用户输入
# input()
# n = int(input("请输入您的真实年龄:"))
# print(n)
# print(n + 1)

# ctrl + / : 快速添加或者取消注释

# death_age = 100
# age = input('请输入您的年龄:')
#
# print(death_age - int(age))


# int(): 转换成整数
# float(): 转换成小数
# str() : 转换成字符串
print(int(3.8))  # 3
print(int("5"))  # 5
# print(int("5.2"))  # 报错
print(int(float("5.2")))  # 5

print(str(10))  # "10"
print(str(10) + "年")  # "10年"
# print(10 + "年")  # 报错
print(10, "年")  # "10 年"


print("ok")
