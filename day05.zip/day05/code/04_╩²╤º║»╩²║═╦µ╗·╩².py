
# 数学函数: 数值操作
print(max(1,2,3,2,1))  # 3
print(max([1,2,3,2,1]))  # 3

print(min(1,2,-3,2,1))  # -3
print(min([1,2,-3,2,1]))  # -3

print(abs(-3))  # 绝对值, 3

print(round(23.456))  # 四舍五入, 23
print(round(23.456, 2))  # 四舍五入,保留2位小数, 23.46

# math模块
import math
print(math.pow(2, 3), pow(2, 3), 2**3)  # 次方

print(math.sqrt(81))  # 开平方根, 9
print(math.pi)  # π, 3.141592653589793

print(math.sin(-270))  # 正弦


# 随机数
import random

# random.choice() : 在列表中随机取一个元素
girls = ['林志玲', '凤姐', '刘亦菲', '贾玲', '李沁']
girlfriend = random.choice(girls)
# girlfriend = random.choice(range(1,10))
print(girlfriend)

# random.randint(start, end): 取值范围:[start, end]
# random.randrange(start, end, step): 取值范围:[start, end)
print(random.randint(1, 3))  # 取整数 (常用)
print(random.randrange(1, 3))  # 取整数


print(random.random())  # 取小数,范围[0,1)
print(random.uniform(2, 5))  # 取小数,范围:[2, 5)

list1 = [1,2,3,4]
random.shuffle(list1)
print(list1)



