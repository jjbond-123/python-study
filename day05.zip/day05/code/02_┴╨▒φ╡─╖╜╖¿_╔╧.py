
# 列表的增删改查

# 增
# append() : 在列表的末尾追加元素
# extend() : 将另一个列表中的元素追加到当前列表
# insert() : 在指定的下标位置插入一个元素.

ages = [2, 3, 4, 5]
ages.append(6)
print(ages)  # [2, 3, 4, 5, 6]

ages = [2, 3, 4, 5]
ages.extend([6, 7, 8])
# ages.append([6, 7, 8]) # [2, 3, 4, 5, [6, 7, 8]]
print(ages)  # [2, 3, 4, 5, 6, 7, 8]

ages = [2, 3, 4, 5]
ages.insert(2, 100)
print(ages)  # [2, 3, 100, 4, 5]


# 删
# pop() : 删除指定下标位置的元素,并返回该元素
# remove() : 删除指定的元素
# clear() : 清空列表
# del

names = ['美国队长', '钢铁侠', '黑豹', '蜘蛛侠', '惊奇队长', '雷神', '灭霸', '绯红女巫']
# res = names.pop()  # 默认弹出最后一个元素
res = names.pop(0)  # 弹出指定下标位置的元素
print(res, names)

ceos = ['马化腾', '马云', '马明哲', '马化腾', '马斯克', '马化腾']
# ceos.remove("马化腾")
# print(ceos)

# count(): 指定元素的个数
print(ceos.count('马化腾'))

# 删除所有的'马化腾'
for _ in range(ceos.count('马化腾')):
    ceos.remove('马化腾')

print(ceos)  # ['马云', '马明哲', '马斯克']

ceos.clear()
print(ceos)  # []

ages = [1,2,3,4,5,6]
del ages[:3]
print(ages)


# 改
ages[0] = 100

# 查
print(ages[0])



