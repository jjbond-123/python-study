# 用for - in语句实现下面的编程题目

# 初级
# 1.求1-100之间可以被7整除的数的个数
# 2.计算从1到100以内所有奇数的和。
# 3.计算从1到100以内所有能被3或者17整除的数的和。


# 4.计算1到100以内能被7或者3整除但不能同时被这两者整除的数的个数。
count = 0
for i in range(1, 101):
    if (i%7==0 or i%3==0) and i%21!=0:
        count += 1
print(count)  # 39


# 5.计算1到500以内能被7整除但不是偶数的数的个数。
count = 0
for i in range(1, 501):
    if i%7==0 and i%2!=0:
        count += 1
print(count)  # 36


# 中级：
# 1.从键盘输入一个数n，判断是不是一个质数（质数是只能被1和它自身整除的数）
# n = int(input("n:"))
# for i in range(2, n//2+1):
#     if n%i == 0:
#         print("不是质数")
#         break
# else:
#     print("是质数")


# 2.求1000以内的水仙花数：水仙花数：一个三位数各个位上的立方之和，等于本身。
# 例如： 153 = 1^3 + 5^3 + 3^3 = 1 + 125 + 27 = 153
for i in range(100, 1000):
    if (i//100)**3 + (i//10%10)**3 + (i%10)**3 == i:
        print(i)


# 3.求2～100之内的素数。【素数：只能被1或本身整除的数】
for n in range(2, 101):

    for i in range(2, n // 2 + 1):
        if n % i == 0:
            break
    else:
        print("素数:", n)

print()
# 4.优化猜数字游戏
#   计算机出一个1~100之间的随机数由人来猜 random.randint(1, 100)
#   计算机根据人猜的数字分别给出提示: 大一点 / 小一点 / 猜对了，
#   这个过程可以循环进行，当进行5次以上还猜不对的话，则打印：智商余额不足
import random
n1 = random.randint(1, 100)
print("n1:", n1)

# for i in range(5):
#     n2 = int(input("你输入的数:"))
#
#     if n2 > n1:
#         print("小一点")
#     elif n2 < n1:
#         print("大一点")
#     else:
#         print("猜对了")
#         break
#
#     if i == 4:
#         print("智商余额不足")
#
# # else:
# #     print("智商余额不足")

i = 0
while i < 5:
    n2 = int(input("你输入的数:"))

    if n2 > n1:
        print("小一点")
    elif n2 < n1:
        print("大一点")
    else:
        print("猜对了")
        break

    # if i == 4:
    #     print("智商余额不足")

    i += 1

else:
    print("智商余额不足")
