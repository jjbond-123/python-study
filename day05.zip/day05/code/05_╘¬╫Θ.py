
# 元组
#   1. 和列表类似
#   2. 区别: ①元组就是不可改变的列表. ②列表使用[],元组使用()
#

# 创建元组
t = ()  # 空元组
t = (1, 2, 3)
t = (1,)  # 只有1个元素的元组,要加逗号
print(t, type(t))

# 元组的基本操作
t = (1,2,3,4,5,6)
print(t[0])
print(t[1])
print(t[2])
print(t[-1])

print(len(t))


# 报错, 不支持修改
# TypeError: 'tuple' object does not support item assignment
# t[2] = 100

print((1,2,3) + (4,5,6))  # (1, 2, 3, 4, 5, 6)

print((1,2,3) * 3)  # (1, 2, 3, 1, 2, 3, 1, 2, 3)

print(3 in (1,2,3))  # True

# 切片
t = (1,2,3,4,5,6)
print(t[2:5])  # (3, 4, 5)
print(t[::-1])  # (6, 5, 4, 3, 2, 1)

# 增删改: 元组不可以修改
# 查: 和列表一样
for n in t:
    print(n)

for i in range(len(t)):
    print(i)

# 排序
# sorted, reversed
t = (11, 22, 9)
print(sorted(t))  # [9, 11, 22]
print(sorted(t, reverse=True))  # [22, 11, 9]

print(tuple(reversed(t)))  # (9, 22, 11)


# 元组中的列表是可以修改的
t = (1, 2, 3, [4, 5])
t[-1][0] = 10
print(t)  # (1, 2, 3, [10, 5])


# 列表和元组的转换
l = list(t)
print(l)  # [1, 2, 3, [10, 5]]
print(tuple(l))  # (1, 2, 3, [10, 5])


a, b, c = (1, 2, 3)
print(a, b, c)


# 交换两个变量的值
x = 20
y = 30

# 重点掌握
# x, y = y, x

# z = x
# x = y
# y = z

# x = x + y
# y = x - y
# x = x - y

# x = x ^ y
# y = x ^ y
# x = x ^ y

print(x, y)  # 30 20







