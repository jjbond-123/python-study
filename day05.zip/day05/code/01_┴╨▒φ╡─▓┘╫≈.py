
# 列表list
# 创建列表
ages = [22, 33, 44, 55, 66, 77]

# 列表的索引/下标
print(ages[0])  # 22
print(ages[-1])  # 77, 倒数第一个

# 遍历列表
for n in ages:
    print(n)

for i in range(len(ages)):
    print(i, ages[i])

for i,n in enumerate(ages):
    print(i, n)

# 从后往前遍历(了解)
for i in range(5, -1, -1):
    print(i)

# print(list(range(10, 1, -1)))  # [10, 9, 8, 7, 6, 5, 4, 3, 2]

# 切片,截取
ages = [1, 2, 3, 4, 5, 6, 7, 8]
print(ages[:])  # [1, 2, 3, 4, 5, 6, 7, 8]
print(ages[2:])  # [3, 4, 5, 6, 7, 8]
print(ages[:6])  # [1, 2, 3, 4, 5, 6]
print(ages[2:6])  # 范围:[2,6), 结果: [3, 4, 5, 6]

print(ages[::-1])  # 倒序: [8, 7, 6, 5, 4, 3, 2, 1]

# print(ages[2::2])  # 最后的2是一个步数step, 结果:[3, 5, 7]
# print(ages[6:2:-1])  # 下标范围:6,5,4,3 . 结果: [7, 6, 5, 4]

# 合并
print([1,2,3] + [4,5,6])  # [1, 2, 3, 4, 5, 6]

# 重复
print([1,2,3] * 3)  # [1, 2, 3, 1, 2, 3, 1, 2, 3]

# 判断成员
print(3 in [1,2,3])  # True
print(3 not in [1,2,3])  # False












