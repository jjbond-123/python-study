
# break
# 作用: 跳出循环
#   1. 可以在for和while中使用
#   2. break之后的代码不会执行
#   3. 当有循环嵌套时,break只会跳出一层循环
for i in range(1, 11):
    print(i)
    if i%3 == 0:
        print("break之前的代码")
        break
        print("break之后的代码")

print()
for i in range(1, 4):
    for j in range(1, 3):
        if j == 2:
            break
        print(f"i={i}, j={j}")


print('ok')

# 求素数(素数又称质数, 只能被1和自身整除,比如3,5,7,11,13,17..)
#  合数:除了1和自身以外,还能被其他数整除,比如,4, 6, 8, 9, 10, 12, 14, 15...
n = 77

b = True
for i in range(2, n//2+1):
    if n%i == 0:
        print("是合数")
        b = False
        break
if b:
    print("是素数")


# for-else : 结合break使用
# while-else : 结合break使用
n = 17
for i in range(2, n):
    if n%i == 0:
        print(n, "是合数")
        break  # 1.如果执行了break,则else不执行, 2.如果没有执行break则会在循环结束之后再执行else中的代码.
else:
    print(n, "是素数")


n = 17
i = 2
while i < n:
    if n%i == 0:
        print(n, "是合数")
        break
    i += 1
else:
    print(n, "是素数")


# continue
#   停止执行当次循环continue后的代码(结束当次循环),然后进入下一次循环
for i in range(1, 11):
    # if i == 3:
    #     continue
    # print(i)

    if i == 3:
        pass  # 空语句, 补全代码, 让代码不报错
    else:
        print(i)



