
# 列表 list
# 创建列表
ages = [2, 3, 4, 5, 6, "hello"]
print(ages)
print(type(ages))

# 索引: 下标
# 因为列表是有序的, 从0开始
print(ages[3])  # 5
print(ages[0])  # 2
# print(ages[9])  # 报错
print(ages[-1])  # 倒数第一个
print(ages[-2])  # 倒数第二个

'''
错误: 列表的下标越界
IndexError: list index out of range
'''

# 设置/修改元素的值
ages[3] = 100
print(ages)  # [2, 3, 4, 100, 6, 'hello']


# 列表的长度: 列表中元素的个数
print(len(ages))  # 6


# 成员in
if 4 in ages:
    print("4是ages的元素")


