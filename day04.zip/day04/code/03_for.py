
# for循环
#   for-in

# 遍历列表的每个元素
name_list = ["杨超越", "范冰冰", "迪丽热巴", "杨幂"]
for name in name_list:
    print(name)

# 计算下面列表的元素和
age_list = [22, 40, 26, 34]
s = 0
for age in age_list:
    s += age

print(s)


# range: 范围
# range(10): [0, 10), 从0-9的整数

print(range(10))  # 序列
print(list(range(10)))  # [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

for i in range(10):
    print(i)

print()
for i in range(2, 6):  # [2,6)
    print(i)

print()
for i in range(2, 10, 3):  # 2, 5, 8
    print(i)


# 计算1~100的和
s = 0
for i in range(1, 101):
    s += i
print(s)


# 遍历列表得到下标
name_list = ["杨超越", "范冰冰", "迪丽热巴", "杨幂"]
for i in range(len(name_list)):
    print(i, name_list[i])


# enumerate 枚举
for i, name in enumerate(name_list):
    print(i, name)


# 1.求1-100之间可以被7整除的数的个数
count = 0
for i in range(1, 101):
    if i%7 == 0:
        count += 1
print(count)


# 2.计算从1到100以内所有奇数的和。
s = 0
for i in range(1, 101):
    if i%2:
        s += i
print(s)


print()
# 循环嵌套
# 打印一个'长方形'
'''
    *******
    *******
    *******
'''
for i in range(3):  # 行
    for j in range(7):  # 列
        print('*', end='')  # 不换行
    print()  # 换行


# 九九乘法表
'''
    1*1=1
    1*2=2 2*2=4
    1*3=3 2*3=6 3*3=9
    ...
    
    
    1*9=9 2*9=18 ...       9*9=81
'''
for i in range(1, 10):  # 行
    for j in range(1, i+1):  # 列
        print(f'{j}*{i}={i*j} ', end='')

    print()  # 换行













