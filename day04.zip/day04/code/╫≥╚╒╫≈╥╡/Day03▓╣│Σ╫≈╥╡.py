''''''
# x = (input())
# print(type(x))


print(100 - 25 * 3 % 4)
print(not [])
print(not {"name": "张三"})
if {"name": "张三"}:
    print(1)

# 1,成绩判定
# 	大于85 优秀
# 	大于等于75小于等于85 良好
# 	大于等于60小于75 及格
# 	小于60  不及格
# score = int(input("请输入您的分数:"))
# if score > 85:
#     print("优秀")
# elif score >= 75:
#     print("良好")
# elif score >= 60:
#     print("及格")
# else:
#     print("不及格")


# 2,判断一个年份是闰年还是平年；
# （1.能被4整除而不能被100整除.（如2004年就是闰年,1800年不是.）
#   2.能被400整除.（如2000年是闰年））
# year = int(input('请输入一个年份:'))
# if (year%4==0 and year%100!=0) or year%400==0:
#     print(year, "是闰年")
# else:
#     print(year, "是平年")


# 3,输入一个月份，然后输出对应月份有多少天，将天数输出(不考虑闰年)
# 比如：
# 输入 6 输出为30
# 输入 2 输出为28
# month = int(input('请输入一个月份:'))
# if month == 2:
#     print(28)
# # elif month == 1 or month == 3 or month == 5 or month == 7 or month == 8 or month == 10 or month == 12:
# elif month in [1,3,5,7,8,10,12]:
#     print(31)
# else:
#     print(30)


# 4. 开发一款软件，根据公式（身高-108）*2=标准体重，可以有10斤左右的浮动。
# 来观察测试者体重是否合适, 输入真实身高(cm)，真实体重(斤)
# height = int(input("请输入身高:"))
# weight = int(input('请输入体重:'))
# s_weight = (height - 108) * 2
#
# # if weight >= s_weight - 10 and weight <= s_weight + 10:
# if s_weight-10 <= weight <= s_weight+10:
#     print("合适")
# else:
#     print("不合适")


# 5, 入职薪水10K，每年涨幅入职薪水的5%，50年后工资多少？
salary = 10
s = salary + 0.05*salary*50
print(s)


# 6, 为抵抗洪水，战士连续作战89小时，编程计算共多少天零多少小时？
hours = 89
print(hours//24, "天,", hours%24, "小时")


# 7, 给定一个5位数，分别把这个数字的万位， 千位，百位、十位、个位算出来并显示。如： 34567
n = 34567
print(n//10000)
print((n//1000)%10)
print((n//100)%10)
print((n//10)%10)
print(n%10)


# 8.分别输入某年某月某日，判断这一天是这一年的第几天？（考虑闰年） (*****)
#     year, month， day
#     提示： 使用多个if单分支
year = int(input("请输入year:"))
month = int(input("请输入month:"))
day = int(input("请输入day:"))
# 2020,11,22
days = day
if month > 1:
    days = days + 31
if month > 2:
    if (year%4==0 and year%100!=0) or year%400==0:
        days += 29
    else:
        days += 28
if month > 3:
    days += 31
if month > 4:
    days += 30
if month > 5:
    days += 31
if month > 6:
    days += 30
if month > 7:
    days += 31
if month > 8:
    days += 31
if month > 9:
    days += 30
if month > 10:
    days += 31
if month > 11:
    days += 30

print(days)


# 9,输入一个时间，输出该时间的下一秒： (*****)
# 	如：23:59:59，
# 	输入：hour, min, sec
# 	输出 0: 0: 0
hour = int(input("hour:"))
min = int(input("min:"))
sec = int(input("sec:"))

sec += 1
if sec == 60:
    sec = 0
    min += 1

    if min == 60:
        min = 0
        hour += 1

        if hour == 24:
            hour = 0

print("%d:%d:%d"%(hour, min, sec))
print("{}:{}:{}".format(hour, min, sec))
print(f"{hour}:{min}:{sec}")

