# 初级：
#
# 1.判断下面标识符是否合法并说明不合法的原因
# 	@abc.com     不合法
# 	123ok        不合法
# 	_xiaoming    合法
# 	Xiaoming_$   不合法
# 	interface    合法
# 	sina@163     不合法


# 2.从控制台输入圆的半径，计算周长和面积, π=3.14
# r = int(input("请输入半径:"))
# c = 2 * 3.14 * r
# s = 3.14 * r * r


# 3.一辆汽车以40km/h的速度行驶,行驶了45678.9km,求所用的时间
speed = 40
s = 45678.9
t = s/speed

# 4.华氏温度转摄氏温度
# 【提示：将华氏温度转换为摄氏温度(F是华氏温度)  F = 1.8C + 32】
F = 200
C = (F - 32)/1.8

# 5.从控制台输入两个数，输出较大的值
# a = int(input("请输入a:"))
# b = int(input("请输入b:"))
# if a > b:
#     print("最大值a是:", a)
# else:
#     print("最大值b是:", b)


# 6.模拟玩骰子游戏，根据骰子点数决定什么惩罚【例如：1.跳舞，2.唱歌....】
import random
n = random.randint(1, 6)  # 随机取1~6中的某一个整数
if n == 1:
    print("跳舞")
elif n == 2:
    print("唱歌")
elif n == 3:
    print("喝酒")
elif n == 4:
    print("再喝一杯")
elif n == 5:
    print("再来一瓶")
else:
    print("再来一打")


# 中级：
# 1.x 为 0-99 取一个数,y 为 0-199 取一个数,如果 x>y 则输出 x， 如果 x 等于 y 则输出 x+y，否则输出y
x = random.randint(0, 99)
y = random.randint(0, 199)
if x > y:
    print(x)
elif x == y:
    print(x+y)
else:
    print(y)


# 2.从控制台输入三个数，输出较大的值
a = int(input("请输入a:"))
b = int(input("请输入b:"))
c = int(input("请输入c:"))
if a>b and a>c:
    print("最大值a是:", a)
elif b>a and b>c:
    print("最大值b是:", b)
elif c>a and c>b:
    print("最大值c是:", c)


# 3.从控制台输入一个三位数，如果是水仙花数就打印“是水仙花数”，否则打印“不是水仙花数”
# 该数的每一位的立方和等于自身的值,比如:153=1^3+5^3+3^3
# 	例如：153=1^3+5^3+3^3
# 	n = 153:
# 	个位：n%10
# 	十位：(n//10)%10
# 	百位：n//100
n = int(input("请输入一个数:"))
if (n%10)**3 + ((n//10)%10)**3 + (n//100)**3 == n:
    print(n, "是水仙花数")
else:
    print(n, "不是水仙花数")


# 高级：
# 1.从控制台输入一个五位数，如果是回文数就打印“是回文数”，否则打印“不是回文数”
#  回文数: 对称的5位数
# 	例如：11111   12321   12221
n = int(input('请输入一个五位数:'))
a = n // 10000
b = (n//1000) % 10
c = (n//10) % 10
d = n%10
if a==d and b==c:
    print(n, "是回文数")
else:
    print(n, "不是回文数")


# 预习内容：list、for循环
#

