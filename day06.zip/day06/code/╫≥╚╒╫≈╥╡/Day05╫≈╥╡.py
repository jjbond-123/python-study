#
# 初级
# 【注：以下6题功能全部自己实现，不能借助于Python内置函数: max, min, sort, reverse】
#
# 1.自定义一个数字列表，获取这个列表中的最小值，并将列表转化为元组
#  ages = [1,2,3,-4,2,1]
#  min = ages[0]
#  for n in ages:
ages = [1, 2, 3, -4, 2, 1]
min1 = ages[0] = 1
for n in ages:
    if n < min1:
        min1 = n

print(min1)


# 2. 自定义一个数字列表，元素为10个 ,找出列表中最大数连同下标一起输出
nums = [1, 2, 3, 4, 5, 3, 2, 1, 0, 2]
max1 = nums[0]
max1_index = 0
for i in range(len(nums)):
    if nums[i] > max1:
        max1 = nums[i]
        max1_index = i

print(max1, max1_index)


# 3. 自定义一个数字列表，求列表中第二大数的下标
nums = [1, 2, 3, 4, 5, 5, 4, 4, 3, 2, 1]
max2 = nums[0]
for n in nums:
    if n > max2:
        max2 = n
# print(max2)  # 5

max3 = nums[0]  # 第二大数
for n in nums:
    if n > max3 and n != max2:
        max3 = n

# print(max3)  # 4
for i in range(len(nums)):
    if max3 == nums[i]:
        print(i, end=', ')  # 3, 6, 7,
print()


# 4. B哥去参加青年歌手大奖赛 ,有10个评委打分 ,(去掉一个最高分一个最低分)求平均分
import random
scores = []
for i in range(10):
    n = random.randint(6, 10)
    scores.append(n)
print(scores)

max1 = scores[0]
min1 = scores[0]
for n in scores:
    if n > max1:
        max1 = n
    if n < min1:
        min1 = n

scores.remove(max1)
scores.remove(min1)

s = 0
for n in scores:
    s += n

avg = s / len(scores)
print(avg)


# 5. 定义元组，存放5个学生的成绩【成绩值自己设定】，获得成绩之和，平均成绩，最小成绩，最大成绩。
scores = (90, 80, 70, 100, 59)
s = 0
min2 = scores[0]
max2 = scores[0]

for n in scores:
    s += n
    if n > max2:
        max2 = n
    if n < min2:
        min2 = n

avg = s / len(scores)
print("成绩和:", s)
print("平均成绩:", avg)
print("最高成绩:", max2)
print("最低成绩:", min2)


# 6. 将一个列表逆序输出, 提示: range(6,-1,-1)
nums = [2, 3, 4, 1, 2, 3, 4]
nums2 = []
for i in range(len(nums)-1, -1, -1):
    nums2.append(nums[i])

print(nums2)  # [4, 3, 2, 1, 4, 3, 2]


# 中级 : 可以使用内置函数
# 1.给定一个列表：将列表中指定的某个元素全部删除
nums = [1, 2, 3, 3, 3, 2, 2, 1]
n = 2
for i in range(nums.count(n)):
    nums.remove(n)
print(nums)

# 2.自定义一个列表，最大的与第一个元素交换，最小的与最后一个元素交换，输出列表
ages = [-2, 2, 3, 4, 1, 3, 1, 10]
max_index = 0
min_index = 0
for i,n in enumerate(ages):
    if n > ages[max_index]:
        max_index = i
    if n < ages[min_index]:
        min_index = i

ages[0], ages[max_index] = ages[max_index], ages[0]
if min_index == 0:
    # 如果第一个数是最小数
    min_index = max_index
ages[-1], ages[min_index] = ages[min_index], ages[-1]

print(ages)  # [10, 2, 3, 4, 0, 3, 1, -2]


# #字典,先不写
# 3.在控制台输入一句英语，获得每个字母出现的次数，注：每个字符作为key，出现的次数作为value生成一个字典


# 4 ,对称列表. 传入一个列表，元素类型与个数皆未知，返回新列表，由原列表的元素正序反序拼接而成;
# 如传入[“One”, “Two” ,”Three”] 返回[“One”, “Two”, “Three” ,”Three” ,”Two”, “One”]
list1 = ["One", "Two", "Three"]
list2 = list1.copy()
list2.reverse()
# print(list1, list2)
list3 = list1 + list2
print(list3)  # ['One', 'Two', 'Three', 'Three', 'Two', 'One']


# 5, 给定一个不存在重复元素的整数列表，例如[6 ,4 ,7 ,2 ,5 ,8]和一个数字，例如10，
# 找出两个元素(或同一个元素加自身)，并且使这两个数的和为给定数字，并打印出来
# 例如[6 ,4 ,7 ,2 ,5 ,8]和数字10. 打印结果为: 6 ,4  2 ,8  5 ,5
# 提示: 循环嵌套
# nums = [6 ,4 ,7 ,2 ,5 ,8]
# for i in range(len(nums)):
#   for j in range(i, len(nums)):
nums = [6, 4, 7, 2, 5, 8]
n = 10
for i in range(len(nums)):
    for j in range(i, len(nums)):
        if nums[i] + nums[j] == 10:
            print(nums[i], nums[j])


# 6, 有一个从小到大排好序的列表。现输入一个数，要求按原来的规律将它插入列表中,
# 如: [2 ,3 ,4 ,56 ,67 ,98]  如插入63, 100
nums = [2, 3, 4, 56, 67, 98]
n = 100
for i in range(len(nums)):
    if n < nums[i]:
        nums.insert(i, n)
        break
else:
    nums.append(n)

print(nums)


# 7 ,列表去重, 将下面的列表中重复的元素去除
# list1 = [1, 2, 3, 5, 4, 4, 4, 5, 5, 3, 2, 1]
list1 = [1, 2, 3, 5, 4, 4, 4, 5, 5, 3, 2, 1]
list2 = []
for n in list1:
    if n not in list2:
        list2.append(n)

print(list2)



