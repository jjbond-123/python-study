
# 集合 set
#   数据类型:
#       不可变类型(基本类型/值类型):
#           int, float, bool, str, tuple, None, bytes
#       可变类型(引用类型):
#           list, dict, set

# set
#   1. 无序
#   2. 唯一

# 创建集合
set1 = {1,2,3,4,3,3}
print(set1)  # {1, 2, 3, 4}

set1 = set()  # 空集合
print(set1)  # set()

# set1 = set([1,2,2])
# print(set1)

# 无序
set2 = {'a', 'b', 'c'}
print(set2)  # {'b', 'c', 'a'}

# int()
# float()
# str()
# list()
# tuple()
# dict()
# set()

t1 = (1, 2, 3)
s1 = set(t1)
print(s1)  # {1, 2, 3}
print(tuple(s1))  # (1, 2, 3)

d1 = {'a': 1, 'b': 2}
s1 = set(d1)
print(s1)  # {'b', 'a'}
# print(dict(s1))  # 报错

# 集合的长度
print(len(s1))

# 遍历
for n in s1:
    print(n)

# 集合的操作
s1 = {1, 2, 3}
s1.add(4)  # 添加1个元素 # {1, 2, 3, 4}
s1.update([5, 6, 7])  # {1, 2, 3, 4, 5, 6, 7}
print(s1)

s1.remove(5)  # {1, 2, 3, 4, 6, 7} # 如果不存在会报错
s1.discard(6)  # 如果不存在不会报错
s1.clear()
print(s1)

# 集合之间的关系
s1 = {1, 2, 3, 4, 5}
s2 = {4, 5, 6, 7, 8}

print(s1 & s2)  # 交集 {4, 5}
print(s1 | s2)  # 并集 {1, 2, 3, 4, 5, 6, 7, 8}
print(s1 - s2)  # 差集 {1, 2, 3}
print(s1 ^ s2)  # 对称差集 {1, 2, 3, 6, 7, 8}
print(s1 > s2)  # s1是否包含s2
print(s1 < s2)  #


# set 可以去重
ages = [1, 2, 3, 4, 3, 2, 2, 2, 2, 2, 1]
ages2 = list(set(ages))
print(ages2)





