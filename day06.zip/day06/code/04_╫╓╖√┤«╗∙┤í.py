

# 字符串: 用单引号或双引号包裹的内容

# 创建字符串
name = "周杰伦"
song = '青花瓷'
description = '我是"周杰伦"'
print(description)  # 我是"周杰伦"

# + 字符串拼接
print( name + song )

# * 重复
print(name * 3)

# len: 字符串长度
print(len(name))

# in: 子字符串是否在name中
print("杰伦" in name)  # True

# 下标
print(name[0])  # 周
print(name[1])  # 杰
print(name[2])  # 伦
print(name[-1])  # 伦

# 切片
s = "I am good"
print(s[5:])
print(s[::-1])  # 'doog ma I'

# 遍历
for c in s:
    print(c, end=" ")

print()
for i in range(len(s)):
    print(i, s[i])


# 转义
# \n 换行
# \t 制表符,tab键
print('hello\nJack')
print('hello\tJack')

# \ 让其右边的字符没有语义
print('hello\\nJack')
print(r'hello\nJack')


# replace() : 替换
s = "hello world"
s2 = s.replace('l', '+')  # he++o wor+d
s2 = s.replace('l', '+', 2)  # he++o world, 默认替换所有, 2表示值替换前2个
print(s2)






