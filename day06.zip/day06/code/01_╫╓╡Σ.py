
# 字典: dict dictionary

# 创建字典
# 键值对:
#   键key:
#     1. 无序
#     2. 唯一
#     3. key只能使用不可变类型的数据
#           主要是用字符串"", 其他的不可变类型:数字,布尔,元组

person = {"name": "鹿晗", "age": 30, "age": 3, 1: 2, (1,2): 3}
print(person)

# 查: 通过key来查找
print(person["name"])
print(person.get("age"))

# print(person['a'])  # 报错
print(person.get("a"))  # 不报错,获取了None
print(person.get("sex", "女"))  # 不报错,获取了"女"

# 其他的创建方式: 了解
dog = dict(name="旺财", like="舔")
dog = dict(zip(["name", "like"], ["旺财", "骨头", "2"]))
dog = dict(zip("abc", 'xyz'))

z = zip(["name", "like"], ["旺财", "骨头", "2"])
print(z, list(z))

dog = dict([("name", '旺财'), ('like', '游泳')])
print(dog)


# 增
cat = {'name': 'tom', 'sex': '公'}
cat['age'] = 3
print(cat)

# 改
cat['sex'] = '母'
print(cat)  # {'name': 'tom', 'sex': '母', 'age': 3}

# 删
cat.pop('sex')  # 删除性别
print(cat)

# cat.popitem()  # 随机删除一项, 了解
# print(cat)

# cat.clear()  # 清空字典
# print(cat)

# del cat['name']
# # del cat
# print(cat)


# 字典的基本操作
# 拼接
d1 = {'a': 1}
d2 = {'b': 2}
# print(d1 + d2)  # 报错, 不可以使用+
d1.update(d2)
print(d1)  # {'a': 1, 'b': 2}

# print(d1 * 3)  # 报错, 不可以使用*

# in: 判断key是否在字典中存在
print('a' in d1)  # True

# len: 字典的长度
print(len(d1))  # 2

# 字典中没有下标,不能使用切片


# 遍历字典: 掌握
d = {'a': 1, 'b': 2, 'c': 3}

for key in d:
    print(key, d[key])

# 单独获取d的所有key
k = d.keys()
print(k)  # dict_keys(['a', 'b', 'c'])
print(list(k))  # ['a', 'b', 'c']


for key in d.keys():
    print(key)

for value in d.values():
    print(value)

for key, value in d.items():
    print(key, value)



'''
list 和 dict的区别:
    list列表:
        1. 定义方式: [1,2,3], 一般存放相同类型的数据.
        2. 内存消耗较小
        3. 数据量增大时,查找所需时间更长(速度更慢)
    dict字典:
        1. 定义方式: {key: value}, 一般存放相同物品的不同属性.
        2. 内存消耗较大
        3. 随着数据量增大,对查找速度影响不大,查询速度很快

'''





