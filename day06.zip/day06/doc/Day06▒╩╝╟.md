### 一、字典Dict

#### 1.概念

> 列表和元组的使用缺点：当存储的数据要动态添加、删除的时候，我们一般使用列表，但是列表有时会遇到一些麻烦
>
> ```python
> # 定义一个列表保存，姓名、性别、职业
> nameList = ['尼古拉斯.赵四', '男', '铁憨憨'];
>
> # 当修改职业的时候，需要记忆元素的下标
> nameList[2] = '演员'  
>
> # 如果列表的顺序发生了变化，添加年龄
> nameList = ['尼古拉斯.赵四', 18, '男',  '铁匠']
>
> # 此时就需要记忆新的下标，才能完成名字的修改
> nameList[3] = 'xiaoxiaoWang'
> ```
>
> 解决方案：既能存储多个数据，还能在访问元素的很方便的定位到需要的元素，采用字典
>
> 语法： {键1: 值1, 键2: 值2, 键3: 值3, ..., 键n: 值n} 
>
> 说明：键值对: key-value
>
> - 字典和列表类似，都可以用来存储多个数据
> - 在列表中查找某个元素时，是根据下标进行的；字典中找某个元素时，是根据'名字'（就是冒号:前面的那个值，例如上面代码中的'name'、'id'、'sex'）
> - 字典中的每个元素都由2部分组成，键:值。例如 'name':'班长' ,'name'为键，'班长'为值
> - 键可以使用数字、布尔值、元组，字符串等不可变数据类型，但是一般习惯使用字符串，切记不能使用列表等可变数据类型
> - 每个字典里的key都是唯一的，如果出现了多个相同的key,后面的value会覆盖之前的value
>
> 习惯使用场景：
>
> - 列表更适合保存相似数据，比如多个商品、多个姓名、多个时间
> - 字典更适合保存不同数据，比如一个商品的不同信息、一个人的不同信息
>

#### 2.定义字典


```python
#语法：字典名 = {key1:value1,key2:value2.....}

#1.创建空字典
dict1 = {}
print(dict1,type(dict1))

#2.创建非空字典
#方式一
dict21 = {"name":"张三","age":18}
print(dict21)

#方式二
#dict(key=value),key是一个变量名，value是一个值
dict22 = dict(a="avvv",b="2353")
print(dict22)
dict22 = dict(a=200,b=33)
print(dict22)

#方式三
#dict()和zip(序列),zip表示映射
#dict(zip([key1,key2,key3....],[value1,value2,value3....]))
#注意：key的数量和value的数量可以不一致，以少的作为参考
z1 = zip([1,2],["a","b","c"])
dict23 = dict(z1)
print(dict23)

dict23 = dict(zip(("name","age"),("aaa",10)))
print(dict23)

dict23 = dict(zip("xyz","abc"))
print(dict23)

#方式四
# [(key1,value1), (key2,value2)...] => {key1:value1, key2:value2....}
dict24 = dict([("a",10),("b",20),("c",30)])
print(dict24)
```



### 二、set集合【了解】

#### 1.概述

> 和数学上的集合基本是一样的，
>
> 特点:不允许有重复元素，可以进行交集，并集，差集的运算
>
> 本质：无序，无重复元素的集合

#### 2.创建

> set(列表或者元组或者字典)
>
> 代码演示：
>
> ```Python
> #注意：set的创建需要借助于list和tuple
>
> #1.通过list创建set
> list1 = [432,5,5,46,65]
> s1 = set(list1)
> print(list1)
> print(s1)
>
> #注意1：set中会自动将重复元素过滤掉
>
> #2.通过tuple创建set
> tuple1 = (235,45,5,656,5)
> s2 = set(tuple1)
> print(tuple1)
> print(s2)
>
> #3.通过dict创建set
> dict1 = {1:"hello",2:"good"}
> s3 = set(dict1)
> print(dict1)   #{1: 'hello', 2: 'good'}
> print(s3)   #{1, 2}
>
> #注意2：set跟dict类似，都使用{}表示，但是与dict之间的区别在于：set中相当于只存储了一组key，没有value
> ```

#### 3.操作

##### 3.1添加

> 代码演示：
>
> ```Python
> #1.添加
> #add()   在set的末尾进行追加
> s1 = set([1,2,3,4,5])
> print(s1)
> s1.add(6)
> print(s1)
>
> #注意：如果元素已经存在，则添加失败
> s1.add(3)
> print(s1)
> #print(s1.add(3))
>
> #s1.add([7,8,9])   #TypeError: unhashable type: 'list'  list是可变的，set中的元素不能是list类型
> s1.add((7,8,9))
> #s1.add({1:"a"})  #TypeError: unhashable type: 'dict'  ，dict中的键值对可以改变，set中的元素不能是dict类型
> print(s1)
>
> #update()   插入【末尾添加】，打碎插入【直接将元组，列表中的元素添加到set中，将字符串中的字母作为小的字符串添加到set中】
> s2 = set([1,2,3,4,5])
> print(s2)
> s2.update([6,7,8])
> s2.update((9,10))
> s2.update("good")
> #注意：不能添加整型，因为整型不能使用for循环遍历
> #s2.update(11)   #TypeError: 'int' object is not iterable
> print(s2)
> ```

##### 3.2删除

> 代码演示：
>
> ```Python
> #2.删除
> #remove()
> s3 = set([1,2,3,4,5])
> print(s3)
> s3.remove(3)
> print(s3)
> ```

##### 3.3遍历

> 代码演示：
>
> ```Python
> #3.set的遍历
> s4 = set([1,2,3,4,5])
> for i in s4:
>     print(i)
>
> #注意：set是没有索引的，所以不能通过s4[2]获取元素，原因：set是无序的
> #print(s4[2])  #TypeError: 'set' object does not support indexing
>
> #注意：获取的是编号和元素值
> for i,num in enumerate(s4):
>     print(i,num)
> ```

##### 3.4交集和并集

> 代码演示：
>
> ```Python
> #4.交集和并集
> s4 = set([1,2,3])
> s5 = set([4,5,3])
>
> #交集：&【按位与】    and
> r1 = s4 & s5
> print(r1)
> print(type(r1))
>
> #并集:|【按位或】   or
> r2 = s4 | s5
> print(r2)
> ```



### 三、排序算法

##### 1. 冒泡排序

> 排序思路：比较两个相邻下标对应的元素，如果以升序为例的话，则最大值出现在最右边
>
> 代码实现：
>
> ```Python
> list1 = [34,5,46,23,23,54,65,54]
>
> #升序排序：冒泡
> #外层循环：控制比较的轮数
> for out in range(0,len(list1) - 1):
>     #内层循环;控制每一轮比较的次数，兼顾参与比较的下标
>     for inner in range(0,len(list1) - out - 1):
>         if list1[inner] > list1[inner + 1]:
>             list1[inner],list1[inner + 1] = list1[inner + 1],list1[inner]
>             
> print(list1)
> ```

##### 2. 选择排序

> 排序思路：固定一个下标，然后拿这个下标对应的元素和其他的元素依次进行比较，最小值出现在最左边
>



### 四、String字符串基础

#### 1.概述

> 由多个字母，数字，特殊字符组成的有限序列
>
> 在Python中，使用单引号或者双引号都可以表示字符串
>
> 注意:没有单符号的数据类型
>
> 'a'   "a"

#### 2.创建字符串

> 代码演示：
>
> ```Python
> str1 = "hello"
> str2 = "abc1234"
> str3 = "***fhhg%%%"
> str4 = "中文"
> ```

#### 3.字符串运算

> 代码演示：
>
> ```Python
> #1.+   字符串连接
> s1 = "welcome"
> s2 = " to China"
> print(s1 + s2)
>
> #注意：在Python中，使用+。只能是字符串和字符串之间。和其他数据类型使用的话不支持
> #print("abc" + 10)
> #print("123" + 1)
> #print(1 + "12" + 12)
> #print("hello" + True)
>
> #2. *   字符串重复
> s3 = "good"
> print(s3 * 3)
>
> #3.获取字符串中的某个字符
> """
> 类似于列表和元组的使用，通过索引来获取指定位置的字符
> 注意索引的取值范围【0~长度 - 1】，同样会出现索引越界
> 访问方式：字符串名称[索引]
> """
> s4 = "abcdef"
> print(s4[1])
> #print(s4[10])  #IndexError: string index out of range
>
> #获取字符串的长度：len()
> #遍历字符串,和list，tuple的用法完全相同
> for element in s4:
>     print(element)
> for index in range(0,len(s4)):
>     print(s4[index])
> for index,str in enumerate(s4):
>     print(index,str)
>
> #4.截取字符串【切片】
> str1 = "hello world"
> #指定区间
> print(str1[3:7])
> #从指定位置到结尾，包含指定位置
> print(str1[3:])
> #从开头到指定位置，但是不包含指定位置
> print(str1[:7])
>
> str2 = "abc123456"
> print(str2[2:5]) #c12
> print(str2[2:])  #c123456
> print(str2[2::2])  #c246
> print(str2[::2])   #ac246
> print(str2[::-1])  #654321cba   倒序
> print(str2[-3:-1])  #45   -1表示最后一个字符
>
> #5.判断一个子字符串是否在原字符串中
> #in  not in
> str3 = "today is a good day"
> print("good"  in str3)
> print("good1"  not in str3)
> ```

#### 4.格式化输出

> 通过%来改变后面字母或者数字的含义，%被称为占位符
>
> ​	%d          整数
>
> ​	%f		浮点型，特点：可以指定小数点后的位数
>
> ​	%s		字符串
>
> 代码演示：
>
> ```Python
> #6.格式化输出
> num = 10
> string1 = "hello"
> print("string1=",string1,"num=",num)
> #注意：变量的书写顺序尽量和前面字符串中出现的顺序保持一致
> print("string1=%s,num=%d"%(string1,num))
>
> f = 12.247
> print("string1=%s,num=%d,f=%f"%(string1,num,f))
> #需求：浮点数保留小数点后两位
> print("string1=%s,num=%d,f=%.2f"%(string1,num,f))    #round(12.247,2)
> ```

#### 5.常用转义字符

> 通过\来改变后面字母或者特殊字符的含义
>
> ​	\t  		相当于tab键
>
> ​	\n		相当于enter键
>
> ​	\b		相当于backspace
>
> 代码演示：
>
> ```Python
> #7.转义字符
> string2 = "hello\tworld"
> string21 = "hello   world"
> print(string2)
> print(string21)
>
> #换行：\n    多行注释
> string3 = "hello\nPython"
> string31 = """hello
> python2354623
> """
> print(string3)
> print(string31)
>
> #需求："hello"
> print("\"hello\"")
>
> #C:\Users\Administrator\Desktop\SZ-Python1805\Day6\视频
> print("C:\\Users\\Administrator\\Desktop")
> #注意;如果一个字符串中有多个字符需要转义，则可以在字符串的前面添加r,可以避免对字符串中的每个特殊字符进行转义
> print(r"C:\Users\Administrator\Desktop")
> ```

​	